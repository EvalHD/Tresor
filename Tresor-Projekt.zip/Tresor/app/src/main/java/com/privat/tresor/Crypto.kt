package com.privat.tresor

import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** Verschluesselung: AES-256-GCM, Schluesselableitung per PBKDF2. */
object Crypto {
    private val rnd = SecureRandom()
    const val CHUNK = 64 * 1024

    fun randomBytes(n: Int): ByteArray = ByteArray(n).also { rnd.nextBytes(it) }

    fun deriveKey(password: CharArray, salt: ByteArray, iterations: Int): ByteArray {
        val spec = PBEKeySpec(password, salt, iterations, 256)
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    /** Kleine Daten verschluesseln: Ergebnis = IV (12 Byte) + Chiffre. */
    fun seal(key: ByteArray, plain: ByteArray): ByteArray {
        val iv = randomBytes(12)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        return iv + c.doFinal(plain)
    }

    fun open(key: ByteArray, blob: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, blob.copyOfRange(0, 12)))
        return c.doFinal(blob, 12, blob.size - 12)
    }

    private fun iv(nonce: ByteArray, counter: Int): ByteArray =
        ByteBuffer.allocate(12).put(nonce).putInt(counter).array()

    private fun aad(last: Boolean): ByteArray = byteArrayOf(if (last) 1.toByte() else 0.toByte())

    private fun readFully(input: InputStream, buf: ByteArray): Int {
        var off = 0
        while (off < buf.size) {
            val r = input.read(buf, off, buf.size - off)
            if (r < 0) break
            off += r
        }
        return off
    }

    private fun readExact(input: InputStream, buf: ByteArray) {
        if (readFully(input, buf) < buf.size) throw IOException("Datei beschaedigt")
    }

    private fun readLen(input: InputStream): Int {
        val b = ByteArray(4)
        val n = readFully(input, b)
        if (n == 0) return -1
        if (n < 4) throw IOException("Datei beschaedigt")
        return ByteBuffer.wrap(b).int
    }

    /** Grosse Dateien in 64-KB-Bloecken verschluesseln. Gibt die Klartext-Groesse zurueck. */
    fun encryptStream(key: ByteArray, input: InputStream, output: OutputStream): Long {
        val ks = SecretKeySpec(key, "AES")
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val nonce = randomBytes(8)
        output.write(nonce)
        var cur = ByteArray(CHUNK)
        var next = ByteArray(CHUNK)
        var curLen = readFully(input, cur)
        var total = 0L
        var counter = 0
        while (true) {
            val nextLen = if (curLen == CHUNK) readFully(input, next) else 0
            val last = nextLen <= 0
            cipher.init(Cipher.ENCRYPT_MODE, ks, GCMParameterSpec(128, iv(nonce, counter)))
            cipher.updateAAD(aad(last))
            val ct = cipher.doFinal(cur, 0, curLen)
            output.write(ByteBuffer.allocate(4).putInt(ct.size).array())
            output.write(ct)
            total += curLen
            if (last) break
            val t = cur
            cur = next
            next = t
            curLen = nextLen
            counter++
        }
        output.flush()
        return total
    }

    fun decryptStream(key: ByteArray, input: InputStream, output: OutputStream) {
        val ks = SecretKeySpec(key, "AES")
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val nonce = ByteArray(8)
        readExact(input, nonce)
        var len = readLen(input)
        if (len < 0) throw IOException("Datei beschaedigt")
        var counter = 0
        while (len >= 0) {
            if (len > CHUNK + 16) throw IOException("Datei beschaedigt")
            val ct = ByteArray(len)
            readExact(input, ct)
            val nextLen = readLen(input)
            val last = nextLen < 0
            cipher.init(Cipher.DECRYPT_MODE, ks, GCMParameterSpec(128, iv(nonce, counter)))
            cipher.updateAAD(aad(last))
            output.write(cipher.doFinal(ct))
            len = nextLen
            counter++
        }
        output.flush()
    }
}
