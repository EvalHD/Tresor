package com.privat.tresor

import android.app.Activity
import android.content.Context
import android.content.DialogInterface
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.CancellationSignal
import javax.crypto.Cipher

object Bio {
    fun available(c: Context): Boolean {
        val bm = c.getSystemService(BiometricManager::class.java) ?: return false
        return bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) ==
            BiometricManager.BIOMETRIC_SUCCESS
    }

    /** onFail bekommt "" wenn der Nutzer nur abgebrochen hat. */
    fun prompt(a: Activity, title: String, cipher: Cipher, onOk: (Cipher) -> Unit, onFail: (String) -> Unit) {
        val executor = a.mainExecutor
        val prompt = BiometricPrompt.Builder(a)
            .setTitle(title)
            .setNegativeButton("Abbrechen", executor, DialogInterface.OnClickListener { _, _ -> })
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .build()
        prompt.authenticate(
            BiometricPrompt.CryptoObject(cipher), CancellationSignal(), executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                    val ci = result?.cryptoObject?.cipher
                    if (ci != null) onOk(ci) else onFail("Fingerabdruck-Fehler")
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                    // 5 = abgebrochen, 10 = vom Nutzer abgebrochen, 13 = Abbrechen-Taste
                    val cancelled = errorCode == 5 || errorCode == 10 || errorCode == 13
                    onFail(if (cancelled) "" else (errString?.toString() ?: "Fingerabdruck-Fehler"))
                }
            }
        )
    }
}
