package com.privat.tresor

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.util.TypedValue
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

object C {
    val BG = Color.parseColor("#0E1117")
    val CARD = Color.parseColor("#181D28")
    val CARD2 = Color.parseColor("#232B3B")
    val ACCENT = Color.parseColor("#4F8CFF")
    val TEXT = Color.parseColor("#F2F5FA")
    val MUTED = Color.parseColor("#8E99AD")
    val ERROR = Color.parseColor("#FF6B6B")
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.rounded(color: Int, radiusDp: Int): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

fun Context.label(t: String, sp: Float = 16f, color: Int = C.TEXT, bold: Boolean = false): TextView {
    val tv = TextView(this)
    tv.text = t
    tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
    tv.setTextColor(color)
    if (bold) tv.setTypeface(tv.typeface, Typeface.BOLD)
    return tv
}

fun Context.button(t: String, filled: Boolean = true): Button {
    val b = Button(this)
    b.text = t
    b.setAllCaps(false)
    b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
    b.setTextColor(if (filled) Color.WHITE else C.ACCENT)
    b.background = rounded(if (filled) C.ACCENT else C.CARD2, 14)
    b.setPadding(dp(16), dp(14), dp(16), dp(14))
    b.stateListAnimator = null
    return b
}

fun Context.input(hint: String, password: Boolean): EditText {
    val e = EditText(this)
    e.hint = hint
    e.setHintTextColor(C.MUTED)
    e.setTextColor(C.TEXT)
    e.setSingleLine()
    e.background = rounded(C.CARD2, 12)
    e.setPadding(dp(16), dp(14), dp(16), dp(14))
    e.inputType = if (password) {
        InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    } else {
        InputType.TYPE_CLASS_TEXT
    }
    return e
}

fun Context.toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

fun Context.lp(
    w: Int = ViewGroup.LayoutParams.MATCH_PARENT,
    h: Int = ViewGroup.LayoutParams.WRAP_CONTENT,
    top: Int = 0,
    weight: Float = 0f
): LinearLayout.LayoutParams {
    val p = LinearLayout.LayoutParams(w, h, weight)
    p.topMargin = dp(top)
    return p
}
