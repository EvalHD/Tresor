package com.privat.tresor

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.CancellationSignal
import android.provider.Settings
import android.service.autofill.AutofillService
import android.service.autofill.Dataset
import android.service.autofill.FillCallback
import android.service.autofill.FillRequest
import android.service.autofill.FillResponse
import android.service.autofill.SaveCallback
import android.service.autofill.SaveInfo
import android.service.autofill.SaveRequest
import android.view.autofill.AutofillManager
import android.view.autofill.AutofillValue
import android.widget.RemoteViews
import java.util.concurrent.atomic.AtomicInteger

/** Erkennt Anmeldeseiten in Apps und Browsern, bietet gespeicherte Zugaenge an und fragt nach dem Speichern. */
class TresorAutofillService : AutofillService() {

    override fun onFillRequest(request: FillRequest, cancellationSignal: CancellationSignal, callback: FillCallback) {
        try {
            val structure = request.fillContexts.lastOrNull()?.structure
            if (structure == null) {
                callback.onSuccess(null)
                return
            }
            val pkg = structure.activityComponent?.packageName ?: ""
            if (pkg == packageName) {
                callback.onSuccess(null)
                return
            }
            val form = FormParser.parse(structure)
            val passId = form.passwordNode?.autofillId
            val userId = form.usernameNode?.autofillId
            if (passId == null && userId == null) {
                callback.onSuccess(null)
                return
            }
            val site = Site.fromForm(form.webDomain, pkg)

            val response = FillResponse.Builder()
            val key = Session.masterKey
            var added = false
            var credCount = -1
            if (key != null) {
                val creds = try {
                    Vault.loadCreds(this, key)
                } catch (e: Exception) {
                    mutableListOf<Cred>()
                }
                credCount = creds.size
                for (c in creds.filter { Site.matchesCred(it, site) }) {
                    val label = if (c.username.isNotEmpty()) "${c.title} · ${c.username}" else c.title
                    val ds = Dataset.Builder(presentation(label))
                    if (passId != null) ds.setValue(passId, AutofillValue.forText(c.password))
                    if (userId != null) ds.setValue(userId, AutofillValue.forText(c.username))
                    response.addDataset(ds.build())
                    added = true
                }
            }
            val offerChooser = key == null || credCount > 0
            if (offerChooser) {
                val showAll = key != null
                val i = Intent(this, FillAuthActivity::class.java)
                    .putExtra("site", site)
                    .putExtra("passId", passId)
                    .putExtra("userId", userId)
                    .putExtra("showAll", showAll)
                val sender = PendingIntent.getActivity(
                    this, reqCode.incrementAndGet(), i,
                    PendingIntent.FLAG_CANCEL_CURRENT or PendingIntent.FLAG_MUTABLE
                ).intentSender
                val text = when {
                    key == null -> "Tresor entsperren"
                    added -> "Anderen Eintrag aus dem Tresor wählen"
                    else -> "Aus dem Tresor wählen"
                }
                val ds = Dataset.Builder(presentation(text))
                if (passId != null) ds.setValue(passId, null)
                if (userId != null) ds.setValue(userId, null)
                ds.setAuthentication(sender)
                response.addDataset(ds.build())
            }

            if (passId != null) {
                val saveBuilder = SaveInfo.Builder(
                    SaveInfo.SAVE_DATA_TYPE_USERNAME or SaveInfo.SAVE_DATA_TYPE_PASSWORD,
                    arrayOf(passId)
                )
                if (userId != null) saveBuilder.setOptionalIds(arrayOf(userId))
                saveBuilder.setFlags(SaveInfo.FLAG_SAVE_ON_ALL_VIEWS_INVISIBLE)
                response.setSaveInfo(saveBuilder.build())
            }

            callback.onSuccess(response.build())
        } catch (e: Exception) {
            callback.onSuccess(null)
        }
    }

    override fun onSaveRequest(request: SaveRequest, callback: SaveCallback) {
        try {
            var form: Form? = null
            var pkg = ""
            for (ctx in request.fillContexts.reversed()) {
                val st = ctx.structure
                val f = FormParser.parse(st)
                if (f.passwordNode != null) {
                    form = f
                    pkg = st.activityComponent?.packageName ?: ""
                    break
                }
            }
            val f = form
            val pass = f?.passwordNode?.autofillValue?.let { if (it.isText) it.textValue.toString() else "" } ?: ""
            if (f == null || pass.isEmpty() || pkg == packageName) {
                callback.onSuccess()
                return
            }
            val user = f.usernameNode?.autofillValue?.let { if (it.isText) it.textValue.toString() else "" } ?: ""
            PendingSave.set(Site.fromForm(f.webDomain, pkg), user, pass)
            val pi = PendingIntent.getActivity(
                this, 1, Intent(this, SaveActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            callback.onSuccess(pi.intentSender)
        } catch (e: Exception) {
            callback.onFailure("Speichern fehlgeschlagen")
        }
    }

    private fun presentation(text: String): RemoteViews {
        val rv = RemoteViews(packageName, R.layout.autofill_item)
        rv.setTextViewText(R.id.autofill_text, text)
        return rv
    }

    companion object {
        private val reqCode = AtomicInteger(100)

        /** Ist der Tresor als Autofill-Dienst eingestellt? */
        fun isActive(c: Context): Boolean {
            val s = try {
                Settings.Secure.getString(c.contentResolver, "autofill_service")
            } catch (e: Exception) {
                null
            }
            if (s != null) return s.startsWith(c.packageName)
            return c.getSystemService(AutofillManager::class.java)?.hasEnabledAutofillServices() == true
        }
    }
}
