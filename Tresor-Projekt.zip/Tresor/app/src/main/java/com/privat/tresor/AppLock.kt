package com.privat.tresor

import android.content.Context
import android.content.Intent
import android.os.SystemClock
import java.security.MessageDigest
import java.util.UUID

/**
 * Verwaltet, welche Apps gesperrt sind und wie lange sie nach dem Entsperren freigegeben bleiben.
 * Die Namen der gesperrten Apps werden nur als Hash gespeichert.
 */
object AppLock {
    @Volatile
    var freeUntil = 0L

    @Volatile
    var lockShowing = false

    @Volatile
    private var lastLaunch = 0L

    private const val SETTINGS_PKG = "com.android.settings"

    private fun prefs(c: Context) = c.getSharedPreferences("applock", Context.MODE_PRIVATE)

    private fun sha(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    private fun salt(c: Context): String {
        val p = prefs(c)
        var s = p.getString("salt", null)
        if (s == null) {
            s = UUID.randomUUID().toString()
            p.edit().putString("salt", s).apply()
        }
        return s
    }

    /** Wird aufgerufen, wenn sich die App-Liste im Hub aendert. */
    fun sync(c: Context, packages: List<String>) {
        val salt = salt(c)
        val set = packages.map { sha(salt + it) }.toSet()
        prefs(c).edit().putStringSet("hashes", set).apply()
    }

    fun isLocked(c: Context, pkg: String): Boolean {
        if (pkg == SETTINGS_PKG && lockSettings(c)) return true
        val set = prefs(c).getStringSet("hashes", null) ?: return false
        return set.contains(sha(salt(c) + pkg))
    }

    // ---------- Freigabe ----------

    fun grant(c: Context) {
        freeUntil = SystemClock.elapsedRealtime() + freeMinutes(c) * 60_000L
    }

    fun revoke() {
        freeUntil = 0L
    }

    fun isFree(): Boolean = SystemClock.elapsedRealtime() < freeUntil

    // ---------- Einstellungen ----------

    fun freeMinutes(c: Context): Int = prefs(c).getInt("freeMinutes", 10)
    fun setFreeMinutes(c: Context, m: Int) = prefs(c).edit().putInt("freeMinutes", m).apply()

    fun screenOff(c: Context): Boolean = prefs(c).getBoolean("screenOff", true)
    fun setScreenOff(c: Context, v: Boolean) = prefs(c).edit().putBoolean("screenOff", v).apply()

    fun lockSettings(c: Context): Boolean = prefs(c).getBoolean("lockSettings", false)
    fun setLockSettings(c: Context, v: Boolean) = prefs(c).edit().putBoolean("lockSettings", v).apply()

    // ---------- Anmelde-Leiste ----------

    fun loginBar(c: Context): Boolean = prefs(c).getBoolean("loginBar", true)
    fun setLoginBar(c: Context, v: Boolean) = prefs(c).edit().putBoolean("loginBar", v).apply()

    /** Merkt (nur als Hash), fuer welche Seiten/Apps Zugangsdaten existieren, damit auch bei gesperrtem Tresor angeboten werden kann. */
    fun syncSites(c: Context, sites: List<String>) {
        val salt = salt(c)
        val set = sites.filter { it.isNotBlank() }.map { sha(salt + "s:" + it) }.toSet()
        prefs(c).edit().putStringSet("siteHashes", set).apply()
    }

    fun hasSite(c: Context, site: String): Boolean {
        val set = prefs(c).getStringSet("siteHashes", null) ?: return false
        val salt = salt(c)
        var s = site
        while (true) {
            if (set.contains(sha(salt + "s:" + s))) return true
            val dot = s.indexOf('.')
            if (dot < 0 || s.indexOf('.', dot + 1) < 0) break
            s = s.substring(dot + 1)
        }
        return false
    }

    // ---------- Sperrbildschirm anzeigen ----------

    fun showLock(c: Context, pkg: String) {
        val now = SystemClock.elapsedRealtime()
        if (lockShowing || now - lastLaunch < 700) return
        lastLaunch = now
        val i = Intent(c, LockActivity::class.java)
            .putExtra("pkg", pkg)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
        c.startActivity(i)
    }
}
