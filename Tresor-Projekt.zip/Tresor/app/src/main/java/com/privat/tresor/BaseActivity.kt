package com.privat.tresor

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.view.WindowManager

/** Verhindert Screenshots und die Vorschau in der App-Uebersicht. */
open class BaseActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
    }
}

/** Seiten, die nur im entsperrten Zustand sichtbar sind. */
open class LockedActivity : BaseActivity() {
    override fun onStart() {
        super.onStart()
        val fromBackground = Session.started == 0
        Session.started++
        val expired = fromBackground && Session.stopTime > 0 &&
            SystemClock.elapsedRealtime() - Session.stopTime > Session.GRACE_MS
        if (Session.masterKey == null || expired) goLogin()
    }

    override fun onStop() {
        super.onStop()
        Session.started = maxOf(0, Session.started - 1)
        if (Session.started == 0) Session.stopTime = SystemClock.elapsedRealtime()
    }

    fun goLogin() {
        Session.lock(this)
        startActivity(Intent(this, StartActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        finish()
    }
}
