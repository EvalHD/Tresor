package com.privat.tresor

import android.app.Activity
import android.security.keystore.KeyPermanentlyInvalidatedException
import android.widget.LinearLayout

/**
 * Passwortfeld plus Fingerabdruck-Knopf. onKey bekommt eine KOPIE des Hauptschluessels;
 * der Aufrufer muss sie nach Gebrauch mit fill(0) loeschen. Der Tresor selbst wird nicht entsperrt.
 */
class UnlockBox(private val a: Activity, buttonText: String, private val onKey: (ByteArray) -> Unit) {
    val view = LinearLayout(a)
    private val pw = a.input("Passwort", true)
    private val err = a.label("", 14f, C.ERROR)
    private val btn = a.button(buttonText)

    init {
        view.orientation = LinearLayout.VERTICAL
        view.addView(pw, a.lp(top = 8))
        view.addView(err, a.lp(top = 8))
        view.addView(btn, a.lp(top = 8))
        btn.setOnClickListener { unlockWithPassword() }
        if (Vault.bioEnabled(a) && Bio.available(a)) {
            val b = a.button("Mit Fingerabdruck", false)
            b.setOnClickListener { unlockWithBio() }
            view.addView(b, a.lp(top = 8))
        }
    }

    private fun unlockWithPassword() {
        val p = pw.text.toString()
        if (p.isEmpty()) return
        err.text = ""
        btn.isEnabled = false
        Thread {
            val key = try {
                Vault.masterWithPassword(a, p.toCharArray())
            } catch (e: Exception) {
                null
            }
            a.runOnUiThread {
                btn.isEnabled = true
                if (key != null) {
                    onKey(key)
                } else {
                    pw.setText("")
                    err.text = "Falsches Passwort."
                }
            }
        }.start()
    }

    fun unlockWithBio() {
        try {
            val cipher = Vault.bioDecryptCipher(a)
            Bio.prompt(
                a, "Tresor entsperren", cipher,
                { c ->
                    val key = Vault.masterWithBio(a, c)
                    if (key != null) onKey(key) else err.text = "Fingerabdruck fehlgeschlagen."
                },
                { msg -> if (msg.isNotEmpty()) err.text = msg }
            )
        } catch (e: KeyPermanentlyInvalidatedException) {
            Vault.disableBio(a)
            err.text = "Fingerabdrücke wurden geändert. Bitte Passwort verwenden."
        } catch (e: Exception) {
            err.text = "Fingerabdruck nicht verfügbar. Bitte Passwort verwenden."
        }
    }
}
