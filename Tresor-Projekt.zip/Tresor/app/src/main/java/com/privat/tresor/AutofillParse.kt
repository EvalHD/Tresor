package com.privat.tresor

import android.app.assist.AssistStructure
import android.app.assist.AssistStructure.ViewNode
import android.os.SystemClock
import android.text.InputType
import android.view.View

/** Hilfen, um Webseiten, App-Paketnamen und Titel intelligent zu vergleichen. */
object Site {
    private val ignoredTokens = setOf(
        "com", "de", "net", "org", "io", "co", "uk", "app", "android", "mobile",
        "www", "m", "login", "signin", "auth", "account", "accounts", "client", "mediaclient"
    )

    fun normalize(raw: String): String {
        var s = raw.trim().lowercase()
        s = s.removePrefix("https://").removePrefix("http://")
        s = s.substringBefore('/').substringBefore('?').substringBefore(':')
        return s.removePrefix("www.")
    }

    fun fromForm(webDomain: String, pkg: String): String =
        if (webDomain.isNotBlank()) normalize(webDomain) else pkg.lowercase()

    private fun coreTokens(raw: String): Set<String> {
        val norm = normalize(raw)
        return norm.split('.', '-', '_', ' ', '+')
            .map { it.trim() }
            .filter { it.length >= 3 && it !in ignoredTokens }
            .toSet()
    }

    fun matches(a: String, b: String): Boolean {
        val na = normalize(a)
        val nb = normalize(b)
        if (na.isBlank() || nb.isBlank()) return false
        if (na == nb || na.endsWith(".$nb") || nb.endsWith(".$na")) return true

        val ta = coreTokens(na)
        val tb = coreTokens(nb)
        if (ta.isEmpty() || tb.isEmpty()) return false

        for (x in ta) {
            for (y in tb) {
                if (x == y) return true
                if (x.length >= 4 && y.length >= 4 && (x.contains(y) || y.contains(x))) return true
            }
        }
        return false
    }

    fun matchesCred(cred: Cred, site: String): Boolean {
        return matches(cred.site, site) || matches(cred.title, site)
    }

    fun displayName(site: String): String {
        val tokens = coreTokens(site)
        val best = tokens.maxByOrNull { it.length } ?: normalize(site)
        return best.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
    }
}

/** Zugangsdaten, die gerade gespeichert werden sollen (nur kurz im Arbeitsspeicher). */
object PendingSave {
    var site = ""
    var user = ""
    var pass = ""
    private var time = 0L

    fun set(site: String, user: String, pass: String) {
        this.site = site
        this.user = user
        this.pass = pass
        time = SystemClock.elapsedRealtime()
    }

    fun valid(): Boolean = (pass.isNotEmpty() || user.isNotEmpty()) && SystemClock.elapsedRealtime() - time < 300_000L

    fun clear() {
        site = ""
        user = ""
        pass = ""
        time = 0L
    }
}

class Form {
    var passwordNode: ViewNode? = null
    var usernameNode: ViewNode? = null
    var webDomain: String = ""
}

/** Findet Benutzername- und Passwortfeld in einer Anmeldeseite (auch bei 2-Schritt-Logins). */
object FormParser {
    fun parse(s: AssistStructure): Form {
        val nodes = ArrayList<ViewNode>()
        val form = Form()
        for (i in 0 until s.windowNodeCount) {
            collect(s.getWindowNodeAt(i).rootViewNode, nodes, form)
        }
        val pwIndex = nodes.indexOfFirst { isPassword(it) }
        if (pwIndex >= 0) {
            form.passwordNode = nodes[pwIndex]
            var user: ViewNode? = null
            for (i in pwIndex - 1 downTo 0) {
                if (isUsername(nodes[i])) {
                    user = nodes[i]
                    break
                }
            }
            if (user == null && pwIndex > 0 && !isPassword(nodes[pwIndex - 1])) user = nodes[pwIndex - 1]
            form.usernameNode = user
        } else {
            // 2-Schritt-Login (z. B. Disney+ Schritt 1: nur E-Mail-Feld sichtbar)
            form.usernameNode = nodes.firstOrNull { isUsername(it) }
        }
        return form
    }

    private fun collect(n: ViewNode, out: MutableList<ViewNode>, form: Form) {
        if (form.webDomain.isEmpty()) {
            val d = n.webDomain
            if (!d.isNullOrEmpty()) form.webDomain = d
        }
        if (n.autofillId != null && n.autofillType == View.AUTOFILL_TYPE_TEXT && n.visibility == View.VISIBLE) {
            out.add(n)
        }
        for (i in 0 until n.childCount) collect(n.getChildAt(i), out, form)
    }

    private fun words(n: ViewNode): String =
        ((n.idEntry ?: "") + " " + (n.hint ?: "") + " " + (n.contentDescription?.toString() ?: "")).lowercase()

    private fun htmlType(n: ViewNode, type: String): Boolean =
        n.htmlInfo?.attributes?.any { it.first.equals("type", true) && it.second.equals(type, true) } == true

    private fun isPassword(n: ViewNode): Boolean {
        val hints = n.autofillHints
        if (hints != null && hints.any { it == View.AUTOFILL_HINT_PASSWORD }) return true
        val cls = n.inputType and InputType.TYPE_MASK_CLASS
        val v = n.inputType and InputType.TYPE_MASK_VARIATION
        if (cls == InputType.TYPE_CLASS_TEXT && (v == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD || v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)
        ) return true
        if (htmlType(n, "password")) return true
        val w = words(n)
        return listOf("password", "passwort", "passwd", "pwd").any { w.contains(it) }
    }

    private fun isUsername(n: ViewNode): Boolean {
        if (isPassword(n)) return false
        val hints = n.autofillHints
        if (hints != null && hints.any { it == View.AUTOFILL_HINT_USERNAME || it == View.AUTOFILL_HINT_EMAIL_ADDRESS }) return true
        val cls = n.inputType and InputType.TYPE_MASK_CLASS
        val v = n.inputType and InputType.TYPE_MASK_VARIATION
        if (cls == InputType.TYPE_CLASS_TEXT && (v == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
                v == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS)
        ) return true
        if (htmlType(n, "email")) return true
        val w = words(n)
        return listOf("user", "email", "e-mail", "mail", "login", "benutzer", "nutzer", "konto", "account").any { w.contains(it) }
    }
}
