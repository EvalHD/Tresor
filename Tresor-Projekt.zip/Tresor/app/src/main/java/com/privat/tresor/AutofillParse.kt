package com.privat.tresor

import android.app.assist.AssistStructure
import android.app.assist.AssistStructure.ViewNode
import android.os.SystemClock
import android.text.InputType
import android.view.View

/** Hilfen, um Webseiten und Apps zu vergleichen. */
object Site {
    fun normalize(raw: String): String {
        var s = raw.trim().lowercase()
        s = s.removePrefix("https://").removePrefix("http://")
        s = s.substringBefore('/').substringBefore('?')
        return s.removePrefix("www.")
    }

    fun fromForm(webDomain: String, pkg: String): String =
        if (webDomain.isNotBlank()) normalize(webDomain) else pkg.lowercase()

    fun matches(a: String, b: String): Boolean {
        if (a.isBlank() || b.isBlank()) return false
        return a == b || a.endsWith(".$b") || b.endsWith(".$a")
    }
}

/** Zugangsdaten, die gerade gespeichert werden sollen (nur kurz im Arbeitsspeicher). */
object PendingSave {
    var site = ""
    var user = ""
    var pass = ""
    private var time = 0L

    fun set(site: String, user: String, pass: String) {
        this.site = site
        this.user = user
        this.pass = pass
        time = SystemClock.elapsedRealtime()
    }

    fun valid(): Boolean = pass.isNotEmpty() && SystemClock.elapsedRealtime() - time < 300_000L

    fun clear() {
        site = ""
        user = ""
        pass = ""
        time = 0L
    }
}

class Form {
    var passwordNode: ViewNode? = null
    var usernameNode: ViewNode? = null
    var webDomain: String = ""
}

/** Findet Benutzername- und Passwortfeld in einer Anmeldeseite. */
object FormParser {
    fun parse(s: AssistStructure): Form {
        val nodes = ArrayList<ViewNode>()
        val form = Form()
        for (i in 0 until s.windowNodeCount) {
            collect(s.getWindowNodeAt(i).rootViewNode, nodes, form)
        }
        val pwIndex = nodes.indexOfFirst { isPassword(it) }
        if (pwIndex < 0) return form
        form.passwordNode = nodes[pwIndex]
        var user: ViewNode? = null
        for (i in pwIndex - 1 downTo 0) {
            if (isUsername(nodes[i])) {
                user = nodes[i]
                break
            }
        }
        if (user == null && pwIndex > 0 && !isPassword(nodes[pwIndex - 1])) user = nodes[pwIndex - 1]
        form.usernameNode = user
        return form
    }

    private fun collect(n: ViewNode, out: MutableList<ViewNode>, form: Form) {
        if (form.webDomain.isEmpty()) {
            val d = n.webDomain
            if (!d.isNullOrEmpty()) form.webDomain = d
        }
        if (n.autofillId != null && n.autofillType == View.AUTOFILL_TYPE_TEXT && n.visibility == View.VISIBLE) {
            out.add(n)
        }
        for (i in 0 until n.childCount) collect(n.getChildAt(i), out, form)
    }

    private fun words(n: ViewNode): String =
        ((n.idEntry ?: "") + " " + (n.hint ?: "") + " " + (n.contentDescription?.toString() ?: "")).lowercase()

    private fun htmlType(n: ViewNode, type: String): Boolean =
        n.htmlInfo?.attributes?.any { it.first.equals("type", true) && it.second.equals(type, true) } == true

    private fun isPassword(n: ViewNode): Boolean {
        val hints = n.autofillHints
        if (hints != null && hints.any { it == View.AUTOFILL_HINT_PASSWORD }) return true
        val cls = n.inputType and InputType.TYPE_MASK_CLASS
        val v = n.inputType and InputType.TYPE_MASK_VARIATION
        if (cls == InputType.TYPE_CLASS_TEXT && (v == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD || v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)
        ) return true
        if (htmlType(n, "password")) return true
        val w = words(n)
        return listOf("password", "passwort", "passwd", "pwd").any { w.contains(it) }
    }

    private fun isUsername(n: ViewNode): Boolean {
        if (isPassword(n)) return false
        val hints = n.autofillHints
        if (hints != null && hints.any { it == View.AUTOFILL_HINT_USERNAME || it == View.AUTOFILL_HINT_EMAIL_ADDRESS }) return true
        val cls = n.inputType and InputType.TYPE_MASK_CLASS
        val v = n.inputType and InputType.TYPE_MASK_VARIATION
        if (cls == InputType.TYPE_CLASS_TEXT && (v == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
                v == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS)
        ) return true
        if (htmlType(n, "email")) return true
        val w = words(n)
        return listOf("user", "email", "e-mail", "mail", "login", "benutzer", "nutzer", "konto", "account").any { w.contains(it) }
    }
}
