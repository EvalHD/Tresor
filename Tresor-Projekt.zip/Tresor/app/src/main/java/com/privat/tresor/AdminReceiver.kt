package com.privat.tresor

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

/** Leerer Geraeteadministrator: Er hat keine Rechte, verhindert aber das Deinstallieren der App. */
class AdminReceiver : DeviceAdminReceiver() {
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence? =
        "Der Deinstallationsschutz wird entfernt. Danach kann der Tresor deinstalliert werden – dabei gehen alle Dateien im Tresor verloren."
}
