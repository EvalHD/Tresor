package com.privat.tresor

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

class MainActivity : LockedActivity() {

    class AppItem(val pkg: String, val label: String, val icon: Drawable?)

    private val items = ArrayList<AppItem>()
    private lateinit var adapter: BaseAdapter
    private lateinit var countText: TextView
    private lateinit var lockStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(C.BG)
        root.setPadding(dp(16), dp(12), dp(16), dp(16))

        // Kopfzeile
        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_lock)
        logo.setColorFilter(C.ACCENT)
        top.addView(logo, lp(dp(24), dp(24)))
        val title = label("Tresor", 22f, C.TEXT, true)
        top.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).also { it.leftMargin = dp(10) })
        val lockBtn = ImageView(this)
        lockBtn.setImageResource(R.drawable.ic_lock)
        lockBtn.setColorFilter(C.TEXT)
        lockBtn.setPadding(dp(10), dp(10), dp(10), dp(10))
        lockBtn.setOnClickListener {
            AppLock.revoke()
            goLogin()
        }
        top.addView(lockBtn, lp(dp(44), dp(44)))
        val moreBtn = ImageView(this)
        moreBtn.setImageResource(R.drawable.ic_more)
        moreBtn.setColorFilter(C.TEXT)
        moreBtn.setPadding(dp(10), dp(10), dp(10), dp(10))
        moreBtn.setOnClickListener { showMenu() }
        top.addView(moreBtn, lp(dp(44), dp(44)))
        root.addView(top, lp())

        root.addView(label("Geschützte Apps", 14f, C.MUTED), lp(top = 12))

        // Feld mit den Apps
        val card = FrameLayout(this)
        card.background = rounded(C.CARD, 20)
        card.setPadding(dp(8), dp(12), dp(8), dp(8))
        val grid = GridView(this)
        grid.numColumns = 4
        grid.verticalSpacing = dp(12)
        grid.stretchMode = GridView.STRETCH_COLUMN_WIDTH
        grid.selector = rounded(0x00000000, 0)
        adapter = object : BaseAdapter() {
            override fun getCount() = items.size
            override fun getItem(position: Int) = items[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val item = items[position]
                val cell = LinearLayout(this@MainActivity)
                cell.orientation = LinearLayout.VERTICAL
                cell.gravity = Gravity.CENTER_HORIZONTAL
                cell.setPadding(dp(2), dp(4), dp(2), dp(4))
                if (item.pkg.isEmpty()) {
                    val plus = TextView(this@MainActivity)
                    plus.text = "+"
                    plus.textSize = 28f
                    plus.setTextColor(C.ACCENT)
                    plus.gravity = Gravity.CENTER
                    plus.background = rounded(C.CARD2, 16)
                    cell.addView(plus, lp(dp(52), dp(52)))
                } else {
                    val img = ImageView(this@MainActivity)
                    img.setImageDrawable(item.icon)
                    cell.addView(img, lp(dp(52), dp(52)))
                }
                val tv = label(item.label, 11f, C.TEXT)
                tv.gravity = Gravity.CENTER
                tv.maxLines = 2
                tv.ellipsize = android.text.TextUtils.TruncateAt.END
                cell.addView(tv, lp(top = 6))
                return cell
            }
        }
        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, pos, _ ->
            val it = items[pos]
            if (it.pkg.isEmpty()) showAddDialog() else launch(it.pkg)
        }
        grid.setOnItemLongClickListener { _, _, pos, _ ->
            val it = items[pos]
            if (it.pkg.isNotEmpty()) confirmRemove(it)
            true
        }
        card.addView(grid, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(card, lp(h = 0, top = 8, weight = 1f))

        // Status der App-Sperre
        lockStatus = label("", 14f, C.TEXT)
        lockStatus.gravity = Gravity.CENTER
        lockStatus.setPadding(dp(14), dp(12), dp(14), dp(12))
        lockStatus.setOnClickListener {
            if (AppLockService.isEnabled(this)) showLockSettings() else showEnableDialog()
        }
        root.addView(lockStatus, lp(top = 12))

        // Ordner unten
        val folder = LinearLayout(this)
        folder.gravity = Gravity.CENTER_VERTICAL
        folder.background = rounded(C.CARD, 20)
        folder.setPadding(dp(16), dp(16), dp(16), dp(16))
        val fIcon = ImageView(this)
        fIcon.setImageResource(R.drawable.ic_folder)
        fIcon.setColorFilter(0xFFFFFFFF.toInt())
        fIcon.setPadding(dp(14), dp(14), dp(14), dp(14))
        fIcon.background = rounded(C.ACCENT, 18)
        folder.addView(fIcon, lp(dp(64), dp(64)))
        val texts = LinearLayout(this)
        texts.orientation = LinearLayout.VERTICAL
        texts.addView(label("Dateien-Tresor", 18f, C.TEXT, true))
        countText = label("", 13f, C.MUTED)
        texts.addView(countText)
        folder.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).also { it.leftMargin = dp(16) })
        folder.addView(label("›", 28f, C.MUTED))
        folder.setOnClickListener { startActivity(Intent(this, FilesActivity::class.java)) }
        root.addView(folder, lp(top = 16))

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (Session.masterKey != null) refresh()
        updateLockStatus()
    }

    private fun updateLockStatus() {
        val on = AppLockService.isEnabled(this)
        lockStatus.text = if (on) "App-Sperre: aktiv  ·  tippen für Einstellungen"
        else "App-Sperre: NICHT aktiv  ·  tippen zum Einrichten"
        lockStatus.setTextColor(if (on) C.ACCENT else C.ERROR)
        lockStatus.background = rounded(if (on) C.CARD else C.CARD2, 14)
    }

    private fun refresh() {
        val idx = try {
            Vault.loadIndex(this)
        } catch (e: Exception) {
            return
        }
        AppLock.sync(this, idx.apps)
        val pm = packageManager
        items.clear()
        for (p in idx.apps) {
            try {
                val ai = pm.getApplicationInfo(p, 0)
                items.add(AppItem(p, pm.getApplicationLabel(ai).toString(), pm.getApplicationIcon(ai)))
            } catch (e: Exception) {
                // App nicht mehr installiert
            }
        }
        items.add(AppItem("", "Hinzufügen", null))
        adapter.notifyDataSetChanged()
        countText.text = if (idx.files.size == 1) "1 Datei" else "${idx.files.size} Dateien"
    }

    private fun launch(pkg: String) {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        AppLock.grant(this)
        if (i != null) startActivity(i) else toast("Diese App lässt sich nicht starten.")
    }

    private fun confirmRemove(app: AppItem) {
        AlertDialog.Builder(this)
            .setTitle(app.label)
            .setMessage("Aus dem Tresor-Hub entfernen? Die App bleibt auf dem Handy installiert.")
            .setPositiveButton("Entfernen") { _, _ ->
                val idx = Vault.loadIndex(this)
                idx.apps.remove(app.pkg)
                Vault.saveIndex(this, idx)
                refresh()
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    // ---------- Apps hinzufügen ----------

    private fun showAddDialog() {
        val wait = AlertDialog.Builder(this).setMessage("Apps werden geladen …").setCancelable(false).show()
        Thread {
            val pm = packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(q, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { AppItem(it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
                .distinctBy { it.pkg }
                .sortedBy { it.label.lowercase() }
            runOnUiThread {
                wait.dismiss()
                if (!isFinishing && Session.masterKey != null) pickApps(list)
            }
        }.start()
    }

    private fun pickApps(list: List<AppItem>) {
        val idx = Vault.loadIndex(this)
        val selected = HashSet<String>(idx.apps)
        val lv = ListView(this)
        lv.adapter = object : BaseAdapter() {
            override fun getCount() = list.size
            override fun getItem(position: Int) = list[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val app = list[position]
                val row = LinearLayout(this@MainActivity)
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(dp(16), dp(8), dp(16), dp(8))
                val img = ImageView(this@MainActivity)
                img.setImageDrawable(app.icon)
                row.addView(img, lp(dp(40), dp(40)))
                val tv = label(app.label, 16f, C.TEXT)
                row.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).also { it.leftMargin = dp(14) })
                val cb = CheckBox(this@MainActivity)
                cb.isChecked = app.pkg in selected
                cb.isClickable = false
                cb.isFocusable = false
                row.addView(cb)
                return row
            }
        }
        lv.setOnItemClickListener { _, view, pos, _ ->
            val pkg = list[pos].pkg
            if (!selected.remove(pkg)) selected.add(pkg)
            val row = view as LinearLayout
            (row.getChildAt(2) as CheckBox).isChecked = pkg in selected
        }
        AlertDialog.Builder(this)
            .setTitle("Apps für den Hub wählen")
            .setView(lv)
            .setPositiveButton("Speichern") { _, _ ->
                val newList = idx.apps.filter { it in selected }.toMutableList()
                for (a in list) if (a.pkg in selected && a.pkg !in newList) newList.add(a.pkg)
                idx.apps.clear()
                idx.apps.addAll(newList)
                Vault.saveIndex(this, idx)
                refresh()
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    // ---------- App-Sperre ----------

    private fun showEnableDialog() {
        val msg = "So schaltest du die App-Sperre ein:\n\n" +
            "1. „Bedienungshilfen öffnen“ tippen.\n" +
            "2. Bei „Installierte Apps“ (oder „Heruntergeladene Apps“) den Tresor wählen und einschalten.\n\n" +
            "Ist der Schalter ausgegraut: „App-Info öffnen“ tippen, oben rechts auf ⋮ und „Eingeschränkte Einstellungen zulassen“ wählen. Danach Schritt 1 wiederholen.\n\n" +
            "Wichtig: In der App-Info unter „Akku“ den Tresor auf „Nicht eingeschränkt“ stellen, damit das Handy die Sperre nicht beendet."
        AlertDialog.Builder(this)
            .setTitle("App-Sperre einrichten")
            .setMessage(msg)
            .setPositiveButton("Bedienungshilfen öffnen") { _, _ ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNeutralButton("App-Info öffnen") { _, _ ->
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }
            .setNegativeButton("Später", null)
            .show()
    }

    private fun showLockSettings() {
        val opts = arrayOf(
            "Freigabezeit: ${AppLock.freeMinutes(this)} Min.",
            "Bei Bildschirm aus sperren: ${if (AppLock.screenOff(this)) "An" else "Aus"}",
            "Einstellungen-App sperren: ${if (AppLock.lockSettings(this)) "An" else "Aus"}",
            "Alle Apps jetzt sperren"
        )
        AlertDialog.Builder(this)
            .setTitle("App-Sperre")
            .setItems(opts) { _, which ->
                when (which) {
                    0 -> chooseMinutes()
                    1 -> {
                        AppLock.setScreenOff(this, !AppLock.screenOff(this))
                        showLockSettings()
                    }
                    2 -> {
                        AppLock.setLockSettings(this, !AppLock.lockSettings(this))
                        showLockSettings()
                    }
                    3 -> {
                        AppLock.revoke()
                        toast("Alle Apps sind jetzt gesperrt.")
                    }
                    else -> {}
                }
            }
            .show()
    }

    private fun chooseMinutes() {
        val vals = intArrayOf(1, 5, 10, 15, 30, 60)
        val names = vals.map { "$it Min." }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Freigabezeit nach dem Entsperren")
            .setSingleChoiceItems(names, vals.indexOf(AppLock.freeMinutes(this))) { d, w ->
                AppLock.setFreeMinutes(this, vals[w])
                d.dismiss()
                showLockSettings()
            }
            .show()
    }

    // ---------- Menü ----------

    private fun showMenu() {
        val bioAvail = Bio.available(this)
        val bioOn = Vault.bioEnabled(this)
        val opts = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        opts.add("Passwort ändern")
        acts.add { changePasswordDialog() }
        if (bioAvail) {
            if (bioOn) {
                opts.add("Fingerabdruck deaktivieren")
                acts.add {
                    Vault.disableBio(this)
                    toast("Fingerabdruck deaktiviert.")
                }
            } else {
                opts.add("Fingerabdruck aktivieren")
                acts.add { enableBio() }
            }
        }
        opts.add("Jetzt sperren")
        acts.add {
            AppLock.revoke()
            goLogin()
        }
        AlertDialog.Builder(this)
            .setItems(opts.toTypedArray()) { _, which -> acts[which]() }
            .show()
    }

    private fun enableBio() {
        try {
            val cipher = Vault.newBioEncryptCipher()
            Bio.prompt(
                this, "Fingerabdruck aktivieren", cipher,
                { c ->
                    try {
                        Vault.enableBio(this, c)
                        toast("Fingerabdruck aktiviert.")
                    } catch (e: Exception) {
                        toast("Fehler: ${e.message}")
                    }
                },
                { msg -> if (msg.isNotEmpty()) toast(msg) }
            )
        } catch (e: Exception) {
            toast("Fehler: ${e.message}")
        }
    }

    private fun changePasswordDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        val old = input("Aktuelles Passwort", true)
        val n1 = input("Neues Passwort (mind. 6 Zeichen)", true)
        val n2 = input("Neues Passwort wiederholen", true)
        box.addView(old, lp(top = 8))
        box.addView(n1, lp(top = 8))
        box.addView(n2, lp(top = 8))
        val dlg = AlertDialog.Builder(this)
            .setTitle("Passwort ändern")
            .setView(box)
            .setPositiveButton("Ändern", null)
            .setNegativeButton("Abbrechen", null)
            .create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val a = n1.text.toString()
                when {
                    !Vault.verifyPassword(this, old.text.toString().toCharArray()) -> toast("Aktuelles Passwort ist falsch.")
                    a.length < 6 -> toast("Das neue Passwort braucht mindestens 6 Zeichen.")
                    a != n2.text.toString() -> toast("Die neuen Passwörter stimmen nicht überein.")
                    else -> {
                        Vault.changePassword(this, a.toCharArray())
                        toast("Passwort geändert.")
                        dlg.dismiss()
                    }
                }
            }
        }
        dlg.show()
    }
}
