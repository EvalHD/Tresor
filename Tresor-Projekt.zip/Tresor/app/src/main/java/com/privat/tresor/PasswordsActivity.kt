package com.privat.tresor

import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PersistableBundle
import android.provider.Settings
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import java.security.SecureRandom
import java.util.UUID

class PasswordsActivity : LockedActivity() {
    private val creds = ArrayList<Cred>()
    private lateinit var adapter: BaseAdapter
    private lateinit var banner: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(C.BG)
        root.setPadding(dp(16), dp(12), dp(16), dp(16))

        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        val back = ImageView(this)
        back.setImageResource(R.drawable.ic_back)
        back.setColorFilter(C.TEXT)
        back.setPadding(dp(10), dp(10), dp(10), dp(10))
        back.setOnClickListener { finish() }
        top.addView(back, lp(dp(44), dp(44)))
        top.addView(
            label("Passwörter", 22f, C.TEXT, true),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).also { it.leftMargin = dp(6) }
        )
        val plus = label("+", 30f, C.ACCENT, true)
        plus.gravity = Gravity.CENTER
        plus.setOnClickListener { editDialog(null) }
        top.addView(plus, lp(dp(44), dp(44)))
        root.addView(top, lp())

        banner = label("", 14f, C.ERROR)
        banner.gravity = Gravity.CENTER
        banner.setPadding(dp(14), dp(12), dp(14), dp(12))
        banner.background = rounded(C.CARD2, 14)
        banner.setOnClickListener { enableAutofill() }
        root.addView(banner, lp(top = 8))

        val box = FrameLayout(this)
        box.background = rounded(C.CARD, 20)
        val lv = ListView(this)
        lv.divider = null
        lv.selector = rounded(0x00000000, 0)
        val empty = label("Noch keine Passwörter.\nSie werden beim Anmelden automatisch angeboten\noder du tippst oben auf „+“.", 15f, C.MUTED)
        empty.gravity = Gravity.CENTER
        adapter = object : BaseAdapter() {
            override fun getCount() = creds.size
            override fun getItem(position: Int) = creds[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val c = creds[position]
                val row = LinearLayout(this@PasswordsActivity)
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(dp(14), dp(10), dp(14), dp(10))
                val ic = ImageView(this@PasswordsActivity)
                ic.setImageResource(R.drawable.ic_key)
                ic.setColorFilter(C.ACCENT)
                ic.setPadding(dp(9), dp(9), dp(9), dp(9))
                ic.background = rounded(C.CARD2, 12)
                row.addView(ic, lp(dp(44), dp(44)))
                val col = LinearLayout(this@PasswordsActivity)
                col.orientation = LinearLayout.VERTICAL
                val t = label(c.title, 16f, C.TEXT, true)
                t.maxLines = 1
                t.ellipsize = TextUtils.TruncateAt.END
                col.addView(t)
                val sub = label(if (c.username.isNotEmpty()) c.username else c.site, 12f, C.MUTED)
                sub.maxLines = 1
                sub.ellipsize = TextUtils.TruncateAt.END
                col.addView(sub)
                row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).also { it.leftMargin = dp(12) })
                return row
            }
        }
        lv.adapter = adapter
        lv.emptyView = empty
        lv.setOnItemClickListener { _, _, pos, _ -> showActions(creds[pos]) }
        box.addView(lv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        box.addView(empty, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(box, lp(h = 0, top = 12, weight = 1f))

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (Session.masterKey != null) refresh()
        updateBanner()
    }

    private fun refresh() {
        val k = Session.masterKey ?: return
        try {
            val list = Vault.loadCreds(this, k).sortedBy { it.title.lowercase() }
            creds.clear()
            creds.addAll(list)
            adapter.notifyDataSetChanged()
        } catch (e: Exception) {
            toast("Fehler beim Laden: ${e.message}")
        }
    }

    private fun update(block: (MutableList<Cred>) -> Unit) {
        val k = Session.masterKey ?: return
        try {
            val list = Vault.loadCreds(this, k)
            block(list)
            Vault.saveCreds(this, k, list)
        } catch (e: Exception) {
            toast("Fehler: ${e.message}")
        }
        refresh()
    }

    // ---------- Autofill-Status ----------

    private fun updateBanner() {
        val on = TresorAutofillService.isActive(this)
        banner.visibility = if (on) View.GONE else View.VISIBLE
        banner.text = "Autofill ist nicht aktiv. Tippen, um den Tresor als Autofill-Dienst festzulegen."
    }

    private fun enableAutofill() {
        AppLock.grant(this)
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_SET_AUTOFILL_SERVICE, Uri.parse("package:$packageName")))
        } catch (e: ActivityNotFoundException) {
            toast("Öffne: Einstellungen → Allgemeine Verwaltung → Passwörter und Autofill → Autofill-Dienst.")
        }
    }

    // ---------- Aktionen ----------

    private fun showActions(c: Cred) {
        AlertDialog.Builder(this)
            .setTitle(c.title)
            .setItems(arrayOf("Passwort kopieren", "Benutzernamen kopieren", "Passwort anzeigen", "Bearbeiten", "Löschen")) { _, which ->
                when (which) {
                    0 -> copy("Passwort", c.password, true)
                    1 -> copy("Benutzername", c.username, false)
                    2 -> AlertDialog.Builder(this)
                        .setTitle(c.title)
                        .setMessage("Benutzer: ${c.username}\n\nPasswort:\n${c.password}")
                        .setPositiveButton("Schließen", null)
                        .show()
                    3 -> editDialog(c)
                    4 -> AlertDialog.Builder(this)
                        .setTitle("Löschen?")
                        .setMessage("„${c.title}“ wird endgültig aus dem Tresor gelöscht.")
                        .setPositiveButton("Löschen") { _, _ -> update { list -> list.removeAll { it.id == c.id } } }
                        .setNegativeButton("Abbrechen", null)
                        .show()
                    else -> {}
                }
            }
            .show()
    }

    private fun copy(label: String, text: String, sensitive: Boolean) {
        val cm = getSystemService(ClipboardManager::class.java)
        val clip = ClipData.newPlainText(label, text)
        if (sensitive && Build.VERSION.SDK_INT >= 33) {
            val extras = PersistableBundle()
            extras.putBoolean("android.content.extra.IS_SENSITIVE", true)
            clip.description.extras = extras
        }
        cm.setPrimaryClip(clip)
        if (sensitive) {
            toast("$label kopiert. Die Zwischenablage wird nach 30 Sekunden geleert.")
            Handler(Looper.getMainLooper()).postDelayed({
                try {
                    cm.clearPrimaryClip()
                } catch (e: Exception) {
                }
            }, 30_000)
        } else {
            toast("$label kopiert.")
        }
    }

    private fun randomPassword(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!#\$%&*+-=?"
        val r = SecureRandom()
        return (1..24).map { chars[r.nextInt(chars.length)] }.joinToString("")
    }

    private fun editDialog(existing: Cred?) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), dp(8))
        val fTitle: EditText = input("Name (z. B. Disney+)", false)
        val fSite: EditText = input("Website oder App (z. B. disneyplus.com)", false)
        val fUser: EditText = input("Benutzername oder E-Mail", false)
        val fPass: EditText = input("Passwort", true)
        fTitle.setText(existing?.title ?: "")
        fSite.setText(existing?.site ?: "")
        fUser.setText(existing?.username ?: "")
        fPass.setText(existing?.password ?: "")
        val show = CheckBox(this)
        show.text = "Passwort anzeigen"
        show.setTextColor(C.TEXT)
        show.setOnCheckedChangeListener { _, on ->
            fPass.inputType = InputType.TYPE_CLASS_TEXT or
                (if (on) InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD else InputType.TYPE_TEXT_VARIATION_PASSWORD)
            fPass.setSelection(fPass.text.length)
        }
        val gen = button("Zufälliges Passwort erzeugen", false)
        gen.setOnClickListener {
            fPass.setText(randomPassword())
            show.isChecked = true
        }
        box.addView(fTitle, lp(top = 8))
        box.addView(fSite, lp(top = 8))
        box.addView(fUser, lp(top = 8))
        box.addView(fPass, lp(top = 8))
        box.addView(show, lp(top = 4))
        box.addView(gen, lp(top = 4))
        val sv = ScrollView(this)
        sv.addView(box)

        AlertDialog.Builder(this)
            .setTitle(if (existing == null) "Neuer Eintrag" else "Eintrag bearbeiten")
            .setView(sv)
            .setPositiveButton("Speichern") { _, _ ->
                val pw = fPass.text.toString()
                val site = Site.normalize(fSite.text.toString())
                val title = fTitle.text.toString().trim().ifEmpty { site.ifEmpty { "Eintrag" } }
                if (pw.isEmpty()) {
                    toast("Bitte ein Passwort eintragen.")
                } else {
                    val entry = Cred(
                        existing?.id ?: UUID.randomUUID().toString(), title, site,
                        fUser.text.toString().trim(), pw, existing?.added ?: System.currentTimeMillis()
                    )
                    update { list ->
                        val i = list.indexOfFirst { it.id == entry.id }
                        if (i >= 0) list[i] = entry else list.add(entry)
                    }
                }
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }
}
