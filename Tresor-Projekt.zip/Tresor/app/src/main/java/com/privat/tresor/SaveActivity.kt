package com.privat.tresor

import android.os.Bundle
import android.view.Gravity
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import java.util.UUID

/** Wird nach einer Anmeldung gestartet: "Passwort im Tresor speichern?" */
class SaveActivity : BaseActivity() {
    private var site = ""
    private var pass = ""
    private lateinit var fTitle: EditText
    private lateinit var fUser: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!PendingSave.valid() || !Vault.isSetUp(this)) {
            toast("Es gibt nichts zu speichern.")
            finish()
            return
        }
        site = PendingSave.site
        pass = PendingSave.pass

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setPadding(dp(28), dp(56), dp(28), dp(28))
        val icon = ImageView(this)
        icon.setImageResource(R.drawable.ic_key)
        icon.setColorFilter(C.ACCENT)
        root.addView(icon, lp(dp(56), dp(56)))
        root.addView(label("Passwort speichern?", 24f, C.TEXT, true), lp(top = 16))
        val sub = label("im Tresor ablegen für:\n$site", 14f, C.MUTED)
        sub.gravity = Gravity.CENTER
        root.addView(sub, lp(top = 6))

        fTitle = input("Name", false)
        fTitle.setText(site)
        root.addView(fTitle, lp(top = 20))
        fUser = input("Benutzername oder E-Mail", false)
        fUser.setText(PendingSave.user)
        root.addView(fUser, lp(top = 10))
        val pwInfo = label("Passwort: ••••••••••", 14f, C.MUTED)
        root.addView(pwInfo, lp(top = 10))

        val key = Session.masterKey
        if (key != null) {
            val save = button("Speichern")
            save.setOnClickListener {
                val k = Session.masterKey
                if (k != null) doSave(k, false) else toast("Der Tresor wurde inzwischen gesperrt. Bitte erneut anmelden.")
            }
            root.addView(save, lp(top = 20))
        } else {
            val box = UnlockBox(this, "Entsperren & speichern") { k -> doSave(k, true) }
            root.addView(box.view, lp(top = 16))
        }
        val cancel = button("Abbrechen", false)
        cancel.setOnClickListener {
            PendingSave.clear()
            finish()
        }
        root.addView(cancel, lp(top = 10))

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(C.BG)
        scroll.isFillViewport = true
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun doSave(key: ByteArray, wipe: Boolean) {
        try {
            val list = Vault.loadCreds(this, key)
            val user = fUser.text.toString().trim()
            val title = fTitle.text.toString().trim().ifEmpty { site }
            val i = list.indexOfFirst { it.site == site && it.username.equals(user, true) }
            if (i >= 0) {
                list[i] = list[i].copy(password = pass, title = title)
            } else {
                list.add(Cred(UUID.randomUUID().toString(), title, site, user, pass, System.currentTimeMillis()))
            }
            Vault.saveCreds(this, key, list)
            PendingSave.clear()
            toast("Im Tresor gespeichert.")
            finish()
        } catch (e: Exception) {
            toast("Fehler beim Speichern: ${e.message}")
        } finally {
            if (wipe) key.fill(0)
        }
    }
}
