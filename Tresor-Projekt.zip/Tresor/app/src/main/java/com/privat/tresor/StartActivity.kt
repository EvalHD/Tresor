package com.privat.tresor

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.security.keystore.KeyPermanentlyInvalidatedException
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

/** Einrichtung (erster Start) und Entsperren. */
class StartActivity : BaseActivity() {
    private var setupMode = false
    private lateinit var pw1: EditText
    private var pw2: EditText? = null
    private var bioSwitch: Switch? = null
    private lateinit var err: TextView
    private lateinit var mainBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Session.masterKey != null) {
            openMain()
            return
        }
        setupMode = !Vault.isSetUp(this)
        buildUi()
        if (!setupMode && Vault.bioEnabled(this) && Bio.available(this)) {
            window.decorView.post { startBioUnlock() }
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setPadding(dp(28), dp(48), dp(28), dp(28))

        val icon = ImageView(this)
        icon.setImageResource(R.drawable.ic_lock)
        icon.setColorFilter(C.ACCENT)
        root.addView(icon, lp(dp(64), dp(64)))

        root.addView(label(if (setupMode) "Tresor einrichten" else "Tresor", 26f, C.TEXT, true), lp(top = 16))
        val sub = label(
            if (setupMode) "Lege ein Passwort fest. Ohne dieses Passwort sind deine Dateien nicht zugänglich – es kann nicht wiederhergestellt werden."
            else "Gib dein Passwort ein, um den Tresor zu öffnen.",
            14f, C.MUTED
        )
        sub.gravity = Gravity.CENTER
        root.addView(sub, lp(top = 8))

        pw1 = input(if (setupMode) "Neues Passwort (mind. 6 Zeichen)" else "Passwort", true)
        root.addView(pw1, lp(top = 28))

        if (setupMode) {
            val p2 = input("Passwort wiederholen", true)
            pw2 = p2
            root.addView(p2, lp(top = 12))
            if (Bio.available(this)) {
                val sw = Switch(this)
                sw.text = "Mit Fingerabdruck entsperren"
                sw.setTextColor(C.TEXT)
                sw.isChecked = true
                bioSwitch = sw
                root.addView(sw, lp(top = 16))
            }
        }

        err = label("", 14f, C.ERROR)
        err.gravity = Gravity.CENTER
        root.addView(err, lp(top = 12))

        mainBtn = button(if (setupMode) "Tresor erstellen" else "Entsperren")
        mainBtn.setOnClickListener { if (setupMode) doSetup() else doUnlock() }
        root.addView(mainBtn, lp(top = 12))

        if (!setupMode && Vault.bioEnabled(this) && Bio.available(this)) {
            val b = button("Mit Fingerabdruck entsperren", false)
            b.setOnClickListener { startBioUnlock() }
            root.addView(b, lp(top = 12))
        }

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(C.BG)
        scroll.isFillViewport = true
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun showError(m: String) {
        err.text = m
    }

    private fun doSetup() {
        val a = pw1.text.toString()
        val b = pw2?.text?.toString() ?: ""
        if (a.length < 6) {
            showError("Das Passwort braucht mindestens 6 Zeichen.")
            return
        }
        if (a != b) {
            showError("Die Passwörter stimmen nicht überein.")
            return
        }
        showError("")
        mainBtn.isEnabled = false
        mainBtn.text = "Bitte warten …"
        Thread {
            try {
                Vault.setup(this, a.toCharArray())
                runOnUiThread { afterSetup() }
            } catch (e: Exception) {
                runOnUiThread {
                    mainBtn.isEnabled = true
                    mainBtn.text = "Tresor erstellen"
                    showError("Fehler: ${e.message}")
                }
            }
        }.start()
    }

    private fun afterSetup() {
        if (bioSwitch?.isChecked == true) {
            try {
                val cipher = Vault.newBioEncryptCipher()
                Bio.prompt(
                    this, "Fingerabdruck aktivieren", cipher,
                    { c ->
                        try {
                            Vault.enableBio(this, c)
                        } catch (e: Exception) {
                            toast("Fingerabdruck konnte nicht aktiviert werden.")
                        }
                        openMain()
                    },
                    { msg ->
                        if (msg.isNotEmpty()) toast(msg)
                        toast("Fingerabdruck nicht aktiviert – das geht später über das Menü.")
                        openMain()
                    }
                )
                return
            } catch (e: Exception) {
                toast("Fingerabdruck nicht aktiviert.")
            }
        }
        openMain()
    }

    private fun doUnlock() {
        val p = pw1.text.toString()
        if (p.isEmpty()) return
        showError("")
        mainBtn.isEnabled = false
        Thread {
            val ok = try {
                Vault.unlockWithPassword(this, p.toCharArray())
            } catch (e: Exception) {
                false
            }
            runOnUiThread {
                mainBtn.isEnabled = true
                if (ok) {
                    openMain()
                } else {
                    pw1.setText("")
                    showError("Falsches Passwort.")
                }
            }
        }.start()
    }

    private fun startBioUnlock() {
        try {
            val cipher = Vault.bioDecryptCipher(this)
            Bio.prompt(
                this, "Tresor entsperren", cipher,
                { c ->
                    if (Vault.unlockWithBio(this, c)) openMain() else showError("Fingerabdruck fehlgeschlagen.")
                },
                { msg -> if (msg.isNotEmpty()) showError(msg) }
            )
        } catch (e: KeyPermanentlyInvalidatedException) {
            Vault.disableBio(this)
            showError("Die Fingerabdrücke auf dem Handy wurden geändert. Bitte mit Passwort entsperren und den Fingerabdruck im Menü neu aktivieren.")
        } catch (e: Exception) {
            showError("Fingerabdruck nicht verfügbar. Bitte Passwort verwenden.")
        }
    }

    private fun openMain() {
        Session.stopTime = 0L
        AppLock.grant(this)
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
