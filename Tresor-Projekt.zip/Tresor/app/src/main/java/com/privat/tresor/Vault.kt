package com.privat.tresor

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.OutputStream
import java.security.KeyStore
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

data class Entry(
    val id: String,
    val name: String,
    val size: Long,
    val mime: String,
    val added: Long,
    val folder: String = ""
)

data class Cred(val id: String, val title: String, val site: String, val username: String, val password: String, val added: Long)

class Index(
    val apps: MutableList<String>,
    val files: MutableList<Entry>,
    val folders: MutableList<String> = mutableListOf()
)

/** Haelt den entsperrten Hauptschluessel nur im Arbeitsspeicher. */
object Session {
    @Volatile
    var masterKey: ByteArray? = null
    var started = 0
    var stopTime = 0L
    const val GRACE_MS = 60_000L // So lange darf die App im Hintergrund sein, bevor sie sich sperrt

    fun lock(ctx: Context) {
        masterKey?.fill(0)
        masterKey = null
        stopTime = 0L
        Vault.clearCache(ctx)
    }
}

object Vault {
    private const val ITER = 200_000
    private const val BIO_ALIAS = "tresor_bio_key"

    private fun metaFile(c: Context) = File(c.filesDir, "vault.json")
    private fun indexFile(c: Context) = File(c.filesDir, "index.enc")
    private fun dataDir(c: Context) = File(c.filesDir, "data").apply { mkdirs() }

    private fun b64(b: ByteArray): String = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun unb64(s: String): ByteArray = Base64.decode(s, Base64.NO_WRAP)

    private fun readMeta(c: Context) = JSONObject(metaFile(c).readText())
    private fun writeMeta(c: Context, m: JSONObject) {
        val tmp = File(c.filesDir, "vault.tmp")
        tmp.writeText(m.toString())
        tmp.renameTo(metaFile(c))
    }

    fun isSetUp(c: Context) = metaFile(c).exists() && indexFile(c).exists()

    // ---------- Einrichtung und Passwort ----------

    fun setup(c: Context, password: CharArray) {
        val master = Crypto.randomBytes(32)
        val salt = Crypto.randomBytes(16)
        val dk = Crypto.deriveKey(password, salt, ITER)
        val meta = JSONObject()
            .put("v", 1)
            .put("salt", b64(salt))
            .put("iter", ITER)
            .put("pw", b64(Crypto.seal(dk, master)))
        dk.fill(0)
        Session.masterKey = master
        saveIndex(c, Index(mutableListOf(), mutableListOf(), mutableListOf()))
        writeMeta(c, meta)
    }

    private fun unwrapWithPassword(c: Context, password: CharArray): ByteArray? {
        val m = readMeta(c)
        val dk = Crypto.deriveKey(password, unb64(m.getString("salt")), m.getInt("iter"))
        return try {
            Crypto.open(dk, unb64(m.getString("pw")))
        } catch (e: Exception) {
            null
        } finally {
            dk.fill(0)
        }
    }

    /** Liefert eine Kopie des Hauptschluessels, ohne den Tresor zu entsperren (null bei falschem Passwort). */
    fun masterWithPassword(c: Context, password: CharArray): ByteArray? = unwrapWithPassword(c, password)

    fun masterWithBio(c: Context, authedCipher: Cipher): ByteArray? {
        return try {
            authedCipher.doFinal(unb64(readMeta(c).getString("bioWrapped")))
        } catch (e: Exception) {
            null
        }
    }

    fun unlockWithPassword(c: Context, password: CharArray): Boolean {
        val k = unwrapWithPassword(c, password) ?: return false
        Session.masterKey = k
        return true
    }

    fun verifyPassword(c: Context, password: CharArray): Boolean {
        val k = unwrapWithPassword(c, password) ?: return false
        k.fill(0)
        return true
    }

    fun changePassword(c: Context, newPassword: CharArray) {
        val master = Session.masterKey ?: return
        val salt = Crypto.randomBytes(16)
        val dk = Crypto.deriveKey(newPassword, salt, ITER)
        val m = readMeta(c)
        m.put("salt", b64(salt)).put("iter", ITER).put("pw", b64(Crypto.seal(dk, master)))
        dk.fill(0)
        writeMeta(c, m)
    }

    // ---------- Fingerabdruck ----------

    fun bioEnabled(c: Context): Boolean = isSetUp(c) && readMeta(c).has("bioWrapped")

    fun newBioEncryptCipher(): Cipher {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (ks.containsAlias(BIO_ALIAS)) ks.deleteEntry(BIO_ALIAS)
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        val spec = KeyGenParameterSpec.Builder(
            BIO_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setUserAuthenticationRequired(true)
            .setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG)
            .setInvalidatedByBiometricEnrollment(true)
            .build()
        kg.init(spec)
        val key = kg.generateKey()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key)
        return cipher
    }

    fun enableBio(c: Context, authedCipher: Cipher) {
        val master = Session.masterKey ?: return
        val wrapped = authedCipher.doFinal(master)
        val m = readMeta(c)
        m.put("bioIv", b64(authedCipher.iv)).put("bioWrapped", b64(wrapped))
        writeMeta(c, m)
    }

    fun disableBio(c: Context) {
        if (isSetUp(c)) {
            val m = readMeta(c)
            m.remove("bioIv")
            m.remove("bioWrapped")
            writeMeta(c, m)
        }
        try {
            val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            if (ks.containsAlias(BIO_ALIAS)) ks.deleteEntry(BIO_ALIAS)
        } catch (e: Exception) {
        }
    }

    /** Kann KeyPermanentlyInvalidatedException werfen, wenn sich die Fingerabdruecke geaendert haben. */
    fun bioDecryptCipher(c: Context): Cipher {
        val m = readMeta(c)
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val key = ks.getKey(BIO_ALIAS, null) as SecretKey
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, unb64(m.getString("bioIv"))))
        return cipher
    }

    fun unlockWithBio(c: Context, authedCipher: Cipher): Boolean {
        return try {
            val m = readMeta(c)
            Session.masterKey = authedCipher.doFinal(unb64(m.getString("bioWrapped")))
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Prueft nur, ob die Fingerabdruck-Freigabe gueltig ist, ohne den Tresor zu entsperren. */
    fun verifyBio(c: Context, authedCipher: Cipher): Boolean {
        return try {
            val k = authedCipher.doFinal(unb64(readMeta(c).getString("bioWrapped")))
            k.fill(0)
            true
        } catch (e: Exception) {
            false
        }
    }

    // ---------- Index (App-Liste, Ordner und Dateiliste, verschluesselt) ----------

    fun loadIndex(c: Context): Index {
        val key = Session.masterKey ?: throw IllegalStateException("gesperrt")
        val o = JSONObject(String(Crypto.open(key, indexFile(c).readBytes()), Charsets.UTF_8))
        val apps = mutableListOf<String>()
        val a = o.optJSONArray("apps")
        if (a != null) for (i in 0 until a.length()) apps.add(a.getString(i))
        val folders = mutableListOf<String>()
        val fl = o.optJSONArray("folders")
        if (fl != null) for (i in 0 until fl.length()) {
            val name = fl.getString(i).trim()
            if (name.isNotEmpty() && folders.none { it.equals(name, true) }) folders.add(name)
        }
        val files = mutableListOf<Entry>()
        val f = o.optJSONArray("files")
        if (f != null) for (i in 0 until f.length()) {
            val e = f.getJSONObject(i)
            val folder = e.optString("folder", "")
            if (folder.isNotEmpty() && folders.none { it.equals(folder, true) }) folders.add(folder)
            files.add(
                Entry(
                    e.getString("id"), e.getString("name"), e.getLong("size"),
                    e.optString("mime", "application/octet-stream"), e.optLong("added"), folder
                )
            )
        }
        return Index(apps, files, folders)
    }

    fun saveIndex(c: Context, idx: Index) {
        val key = Session.masterKey ?: throw IllegalStateException("gesperrt")
        val o = JSONObject()
        o.put("apps", JSONArray(idx.apps))
        o.put("folders", JSONArray(idx.folders))
        val f = JSONArray()
        for (e in idx.files) {
            f.put(
                JSONObject().put("id", e.id).put("name", e.name).put("size", e.size)
                    .put("mime", e.mime).put("added", e.added).put("folder", e.folder)
            )
        }
        o.put("files", f)
        val blob = Crypto.seal(key, o.toString().toByteArray(Charsets.UTF_8))
        val tmp = File(c.filesDir, "index.tmp")
        tmp.writeBytes(blob)
        tmp.renameTo(indexFile(c))
    }

    // ---------- Passwoerter (verschluesselt in creds.enc) ----------

    private fun credsFile(c: Context) = File(c.filesDir, "creds.enc")

    fun loadCreds(c: Context, key: ByteArray): MutableList<Cred> {
        val f = credsFile(c)
        val list = mutableListOf<Cred>()
        if (!f.exists()) return list
        val arr = JSONArray(String(Crypto.open(key, f.readBytes()), Charsets.UTF_8))
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(
                Cred(
                    o.getString("id"), o.optString("title"), o.optString("site"),
                    o.optString("user"), o.optString("pass"), o.optLong("added")
                )
            )
        }
        return list
    }

    fun saveCreds(c: Context, key: ByteArray, list: List<Cred>) {
        val arr = JSONArray()
        for (e in list) {
            arr.put(
                JSONObject().put("id", e.id).put("title", e.title).put("site", e.site)
                    .put("user", e.username).put("pass", e.password).put("added", e.added)
            )
        }
        val blob = Crypto.seal(key, arr.toString().toByteArray(Charsets.UTF_8))
        val tmp = File(c.filesDir, "creds.tmp")
        tmp.writeBytes(blob)
        tmp.renameTo(credsFile(c))
        AppLock.syncSites(c, list.map { it.site })
    }

    // ---------- Ordner & Dateien ----------

    fun createFolder(c: Context, rawName: String): Boolean {
        val name = rawName.trim()
        if (name.isEmpty()) return false
        val idx = loadIndex(c)
        if (idx.folders.any { it.equals(name, true) }) return false
        idx.folders.add(name)
        saveIndex(c, idx)
        return true
    }

    fun renameFolder(c: Context, oldName: String, rawNewName: String): Boolean {
        val newName = rawNewName.trim()
        if (newName.isEmpty()) return false
        val idx = loadIndex(c)
        if (idx.folders.any { it.equals(newName, true) && !it.equals(oldName, true) }) return false
        val pos = idx.folders.indexOfFirst { it == oldName }
        if (pos >= 0) idx.folders[pos] = newName else idx.folders.add(newName)
        for (i in idx.files.indices) {
            if (idx.files[i].folder == oldName) {
                idx.files[i] = idx.files[i].copy(folder = newName)
            }
        }
        saveIndex(c, idx)
        return true
    }

    fun deleteFolder(c: Context, name: String) {
        val idx = loadIndex(c)
        idx.folders.removeAll { it == name }
        for (i in idx.files.indices) {
            if (idx.files[i].folder == name) {
                idx.files[i] = idx.files[i].copy(folder = "")
            }
        }
        saveIndex(c, idx)
    }

    fun moveFile(c: Context, e: Entry, targetFolder: String) {
        val idx = loadIndex(c)
        val pos = idx.files.indexOfFirst { it.id == e.id }
        if (pos >= 0) {
            idx.files[pos] = idx.files[pos].copy(folder = targetFolder)
            if (targetFolder.isNotEmpty() && idx.folders.none { it.equals(targetFolder, true) }) {
                idx.folders.add(targetFolder)
            }
            saveIndex(c, idx)
        }
    }

    fun importUri(c: Context, uri: Uri, folder: String = ""): Entry {
        val key = Session.masterKey ?: throw IllegalStateException("gesperrt")
        var name = "Datei"
        c.contentResolver.query(uri, null, null, null, null)?.use { cur ->
            if (cur.moveToFirst()) {
                val ni = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (ni >= 0) cur.getString(ni)?.let { name = it }
            }
        }
        val mime = c.contentResolver.getType(uri) ?: "application/octet-stream"
        val id = UUID.randomUUID().toString()
        val out = File(dataDir(c), "$id.enc")
        val size: Long = try {
            val input = c.contentResolver.openInputStream(uri) ?: throw IllegalStateException("Datei nicht lesbar")
            input.use { ins -> FileOutputStream(out).use { os -> Crypto.encryptStream(key, ins, os) } }
        } catch (e: Exception) {
            out.delete()
            throw e
        }
        val entry = Entry(id, name, size, mime, System.currentTimeMillis(), folder)
        val idx = loadIndex(c)
        if (folder.isNotEmpty() && idx.folders.none { it.equals(folder, true) }) {
            idx.folders.add(folder)
        }
        idx.files.add(entry)
        saveIndex(c, idx)
        return entry
    }

    fun decryptTo(c: Context, e: Entry, out: OutputStream) {
        val key = Session.masterKey ?: throw IllegalStateException("gesperrt")
        FileInputStream(File(dataDir(c), "${e.id}.enc")).use { Crypto.decryptStream(key, it, out) }
    }

    fun decryptToCache(c: Context, e: Entry): File {
        val dir = File(c.cacheDir, "open").apply { mkdirs() }
        var safe = e.name.replace(Regex("[^A-Za-z0-9._ -]"), "_")
        if (safe.isBlank()) safe = "datei"
        val f = File(dir, safe)
        FileOutputStream(f).use { decryptTo(c, e, it) }
        return f
    }

    fun removeFile(c: Context, e: Entry) {
        File(dataDir(c), "${e.id}.enc").delete()
        val idx = loadIndex(c)
        idx.files.removeAll { it.id == e.id }
        saveIndex(c, idx)
    }

    fun clearCache(c: Context) {
        File(c.cacheDir, "open").deleteRecursively()
    }
}
