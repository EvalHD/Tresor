package com.privat.tresor

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager

/**
 * 1) Sperrt die Apps aus dem Hub (Sperrbildschirm davor).
 * 2) Zeigt auf Anmeldeseiten eine Leiste zum Einfuegen oder Speichern von Passwoertern.
 */
class AppLockService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var activePkg: String? = null
    private var currentPkg: String? = null
    private var scanPending = false
    private val assist by lazy { LoginAssist(this) }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_SCREEN_OFF) {
                assist.hide()
                if (AppLock.screenOff(this@AppLockService)) {
                    AppLock.revoke()
                    activePkg = null
                }
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        val filter = IntentFilter(Intent.ACTION_SCREEN_OFF)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(screenReceiver, filter)
        }
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(screenReceiver)
        } catch (e: Exception) {
        }
        assist.hide()
        super.onDestroy()
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.packageName?.toString() == packageName) return
        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                handleLock(event)
                scheduleScan(350)
            }
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> {
                assist.onTextChanged(event)
                scheduleScan(450)
            }
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
            AccessibilityEvent.TYPE_VIEW_FOCUSED -> scheduleScan(450)
        }
    }

    private fun scheduleScan(delayMs: Long = 450) {
        if (scanPending) return
        scanPending = true
        handler.postDelayed({
            scanPending = false
            val pm = getSystemService(PowerManager::class.java)
            if (pm != null && pm.isInteractive) {
                try {
                    assist.scan()
                } catch (e: Exception) {
                }
            }
        }, delayMs)
    }

    private fun handleLock(event: AccessibilityEvent) {
        val pkg = event.packageName?.toString() ?: return
        if (pkg == "com.android.systemui" || pkg == "android" || isIme(pkg)) return
        currentPkg = pkg

        if (!AppLock.isLocked(this, pkg)) {
            activePkg = null
            return
        }
        if (AppLock.isFree()) {
            activePkg = pkg
            return
        }
        if (pkg == activePkg) return

        AppLock.showLock(this, pkg)
        handler.postDelayed({
            if (currentPkg == pkg && !AppLock.lockShowing && !AppLock.isFree()) {
                performGlobalAction(GLOBAL_ACTION_HOME)
            }
        }, 1200)
    }

    private fun isIme(pkg: String): Boolean {
        val imm = getSystemService(InputMethodManager::class.java) ?: return false
        return imm.enabledInputMethodList.any { it.packageName == pkg }
    }

    companion object {
        fun isEnabled(c: Context): Boolean {
            val s = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
                ?: return false
            val cn = ComponentName(c, AppLockService::class.java)
            return s.split(':').any {
                it.equals(cn.flattenToString(), true) || it.equals(cn.flattenToShortString(), true)
            }
        }
    }
}
