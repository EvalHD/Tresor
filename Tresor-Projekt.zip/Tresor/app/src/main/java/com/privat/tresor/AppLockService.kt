package com.privat.tresor

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager

/** Merkt, welche App nach vorn kommt, und legt bei gesperrten Apps den Sperrbildschirm davor. */
class AppLockService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var activePkg: String? = null
    private var currentPkg: String? = null

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_SCREEN_OFF && AppLock.screenOff(this@AppLockService)) {
                AppLock.revoke()
                activePkg = null
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        val filter = IntentFilter(Intent.ACTION_SCREEN_OFF)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(screenReceiver, filter)
        }
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(screenReceiver)
        } catch (e: Exception) {
        }
        super.onDestroy()
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui" || pkg == "android" || isIme(pkg)) return
        currentPkg = pkg

        if (!AppLock.isLocked(this, pkg)) {
            activePkg = null
            return
        }
        if (AppLock.isFree()) {
            activePkg = pkg
            return
        }
        // Eine App, die gerade benutzt wird, wird nicht mittendrin gesperrt
        if (pkg == activePkg) return

        AppLock.showLock(this, pkg)
        // Notbremse: Falls der Sperrbildschirm nicht erscheint, zurueck zum Startbildschirm
        handler.postDelayed({
            if (currentPkg == pkg && !AppLock.lockShowing && !AppLock.isFree()) {
                performGlobalAction(GLOBAL_ACTION_HOME)
            }
        }, 1200)
    }

    private fun isIme(pkg: String): Boolean {
        val imm = getSystemService(InputMethodManager::class.java) ?: return false
        return imm.enabledInputMethodList.any { it.packageName == pkg }
    }

    companion object {
        fun isEnabled(c: Context): Boolean {
            val s = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
                ?: return false
            val cn = ComponentName(c, AppLockService::class.java)
            return s.split(':').any {
                it.equals(cn.flattenToString(), true) || it.equals(cn.flattenToShortString(), true)
            }
        }
    }
}
