package com.privat.tresor

import android.content.Intent
import android.os.Bundle
import android.security.keystore.KeyPermanentlyInvalidatedException
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Sperrbildschirm, der vor eine gesperrte App gelegt wird. */
class LockActivity : BaseActivity() {
    private var target = ""
    private var bioShowing = false
    private lateinit var pw: EditText
    private lateinit var err: TextView
    private lateinit var btn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        target = intent.getStringExtra("pkg") ?: ""
        if (!Vault.isSetUp(this)) {
            AppLock.grant(this)
            finish()
            return
        }
        AppLock.lockShowing = true

        var appLabel = "Diese App"
        val icon = ImageView(this)
        try {
            val ai = packageManager.getApplicationInfo(target, 0)
            appLabel = packageManager.getApplicationLabel(ai).toString()
            icon.setImageDrawable(packageManager.getApplicationIcon(ai))
        } catch (e: Exception) {
            icon.setImageResource(R.drawable.ic_lock)
            icon.setColorFilter(C.ACCENT)
        }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setPadding(dp(28), dp(64), dp(28), dp(28))
        root.addView(icon, lp(dp(72), dp(72)))
        root.addView(label("Gesperrt", 26f, C.TEXT, true), lp(top = 16))
        val sub = label("$appLabel ist durch den Tresor geschützt.", 14f, C.MUTED)
        sub.gravity = Gravity.CENTER
        root.addView(sub, lp(top = 8))

        pw = input("Passwort", true)
        root.addView(pw, lp(top = 28))
        err = label("", 14f, C.ERROR)
        err.gravity = Gravity.CENTER
        root.addView(err, lp(top = 12))
        btn = button("Entsperren")
        btn.setOnClickListener { doUnlock() }
        root.addView(btn, lp(top = 12))

        val bioOn = Vault.bioEnabled(this) && Bio.available(this)
        if (bioOn) {
            val b = button("Mit Fingerabdruck entsperren", false)
            b.setOnClickListener { startBio() }
            root.addView(b, lp(top = 12))
        }

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(C.BG)
        scroll.isFillViewport = true
        scroll.addView(root)
        setContentView(scroll)

        if (bioOn) window.decorView.post { startBio() }
    }

    private fun doUnlock() {
        val p = pw.text.toString()
        if (p.isEmpty()) return
        err.text = ""
        btn.isEnabled = false
        Thread {
            val ok = try {
                Vault.verifyPassword(this, p.toCharArray())
            } catch (e: Exception) {
                false
            }
            runOnUiThread {
                btn.isEnabled = true
                if (ok) {
                    unlocked()
                } else {
                    pw.setText("")
                    err.text = "Falsches Passwort."
                }
            }
        }.start()
    }

    private fun startBio() {
        if (bioShowing) return
        try {
            val cipher = Vault.bioDecryptCipher(this)
            bioShowing = true
            Bio.prompt(
                this, "App entsperren", cipher,
                { c ->
                    bioShowing = false
                    if (Vault.verifyBio(this, c)) unlocked() else err.text = "Fingerabdruck fehlgeschlagen."
                },
                { msg ->
                    bioShowing = false
                    if (msg.isNotEmpty()) err.text = msg
                }
            )
        } catch (e: KeyPermanentlyInvalidatedException) {
            Vault.disableBio(this)
            err.text = "Fingerabdrücke wurden geändert. Bitte Passwort verwenden."
        } catch (e: Exception) {
            err.text = "Fingerabdruck nicht verfügbar. Bitte Passwort verwenden."
        }
    }

    private fun unlocked() {
        AppLock.grant(this)
        packageManager.getLaunchIntentForPackage(target)?.let { startActivity(it) }
        finish()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }

    override fun onStop() {
        super.onStop()
        if (!isFinishing && !bioShowing) finish()
    }

    override fun onDestroy() {
        AppLock.lockShowing = false
        super.onDestroy()
    }
}
