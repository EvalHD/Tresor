package com.privat.tresor

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Bundle
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import java.util.UUID

/** Zugangsdaten, die nach dem Entsperren im Tresor sofort eingefuegt werden sollen. */
object A11yFill {
    @Volatile
    private var cred: Cred? = null
    private var time = 0L

    fun set(c: Cred) {
        cred = c
        time = SystemClock.elapsedRealtime()
    }

    fun take(): Cred? {
        val c = cred
        cred = null
        return if (c != null && SystemClock.elapsedRealtime() - time < 30_000L) c else null
    }
}

class LoginForm(
    val pkg: String,
    val site: String,
    val pass: AccessibilityNodeInfo?,
    val user: AccessibilityNodeInfo?
)

/**
 * Zeigt oben am Bildschirm eine kleine Leiste (✗ / ✓):
 * 1) Wenn gespeicherte Daten fuer diese App/Seite existieren -> direkt einfuegen.
 * 2) Wenn ein neues Passwort eingetippt wird -> "Moechtest du dieses Passwort speichern?"
 */
class LoginAssist(private val svc: AccessibilityService) {
    private val wm = svc.getSystemService(WindowManager::class.java)
    private var bar: View? = null
    private var shownKey: String? = null
    private var dismissedKey: String? = null

    // Merkt sich E-Mail/Benutzername fuer 2-Schritt-Logins (z. B. Disney+)
    private var rememberedSite: String = ""
    private var rememberedUser: String = ""
    private var rememberedTime: Long = 0L

    private val urlRegex = Regex("^(https?://)?([a-z0-9-]+\.)+[a-z]{2,}(:\d+)?(/\S*)?$", RegexOption.IGNORE_CASE)

    fun onTextChanged(event: AccessibilityEvent) {
        val pkg = event.packageName?.toString() ?: return
        if (pkg == svc.packageName || pkg == "com.android.systemui" || isIme(pkg)) return
        val txt = event.text?.joinToString("")?.trim() ?: ""
        if (txt.isNotEmpty() && !event.isPassword && txt.contains("@")) {
            rememberedUser = txt
            rememberedSite = pkg.lowercase()
            rememberedTime = SystemClock.elapsedRealtime()
        }
    }

    fun scan() {
        if (!AppLock.loginBar(svc) || !Vault.isSetUp(svc)) {
            hide()
            return
        }
        val root = svc.rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: return
        if (pkg == svc.packageName || pkg == "com.android.systemui" || isIme(pkg)) return

        val form = findForm(root, pkg)
        if (form == null) {
            hide()
            dismissedKey = null
            shownKey = null
            return
        }

        // Benutzername fuer 2-Schritt-Logins merken
        val typedUser = readText(form.user)
        if (typedUser.isNotEmpty()) {
            rememberedUser = typedUser
            rememberedSite = form.site
            rememberedTime = SystemClock.elapsedRealtime()
        }
        val effectiveUser = typedUser.ifEmpty {
            if (SystemClock.elapsedRealtime() - rememberedTime < 120_000L &&
                (rememberedSite == form.site || rememberedSite == pkg.lowercase())
            ) rememberedUser else ""
        }

        val typedPass = readText(form.pass)
        val hasTypedPass = typedPass.length >= 3

        val fillKey = "fill|${form.pkg}|${form.site}"
        val saveKey = "save|${form.pkg}|${form.site}|${typedPass.length}"

        // Falls gerade aus dem Tresor eine Auswahl zurueckkam -> sofort einfuegen
        val pending = A11yFill.take()
        if (pending != null) {
            fill(form, pending)
            dismissedKey = fillKey
            hide()
            return
        }

        val k = Session.masterKey
        val matches = if (k != null) {
            try {
                Vault.loadCreds(svc, k).filter { Site.matchesCred(it, form.site) }
            } catch (e: Exception) {
                emptyList()
            }
        } else {
            emptyList()
        }

        // 1) SPEICHERN-LEISTE: Nutzer hat ein Passwort eingetippt
        if (hasTypedPass) {
            val isMasked = typedPass.all { it == '•' || it == '*' || it == '●' }
            val alreadySaved = !isMasked && matches.any { it.password == typedPass }
            if (!alreadySaved) {
                if (saveKey == dismissedKey || saveKey == shownKey) return
                val label = Site.displayName(form.site)
                show(saveKey, "Passwort für „$label“ speichern?") {
                    savePassword(form.site, effectiveUser, if (isMasked) "" else typedPass)
                }
                return
            }
        }

        // 2) EINFUEGEN-LEISTE: Gespeicherte Daten fuer diese App/Seite vorschlagen
        if (fillKey == dismissedKey || fillKey == shownKey) return

        if (k != null) {
            when {
                matches.isEmpty() -> hide()
                matches.size == 1 -> show(fillKey, "Anmeldedaten für „${matches[0].title}“ einfügen?") {
                    val r = svc.rootInActiveWindow
                    val f = if (r != null) findForm(r, pkg) else null
                    if (f != null) fill(f, matches[0])
                }
                else -> show(fillKey, "${matches.size} Einträge für ${Site.displayName(form.site)}. Auswählen?") {
                    openChooser(form.site)
                }
            }
        } else {
            if (AppLock.hasSite(svc, form.site)) {
                show(fillKey, "Tresor entsperren & für ${Site.displayName(form.site)} einfügen?") {
                    openChooser(form.site)
                }
            } else {
                hide()
            }
        }
    }

    private fun savePassword(site: String, user: String, pass: String) {
        val k = Session.masterKey
        if (k != null && pass.isNotEmpty()) {
            try {
                val list = Vault.loadCreds(svc, k)
                val title = Site.displayName(site)
                val existingIdx = list.indexOfFirst { Site.matchesCred(it, site) && it.username.equals(user, true) }
                if (existingIdx >= 0) {
                    val old = list[existingIdx]
                    list[existingIdx] = old.copy(password = pass, site = site, added = System.currentTimeMillis())
                } else {
                    list.add(Cred(UUID.randomUUID().toString(), title, site, user, pass, System.currentTimeMillis()))
                }
                Vault.saveCreds(svc, k, list)
                Toast.makeText(svc, "Passwort für $title gespeichert", Toast.LENGTH_SHORT).show()
                return
            } catch (e: Exception) {
            }
        }
        // Falls Tresor gesperrt oder Passwort von Android maskiert war -> SaveActivity oeffnen
        PendingSave.set(site, user, pass)
        val i = Intent(svc, SaveActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            svc.startActivity(i)
        } catch (e: Exception) {
        }
    }

    // ---------- Formular suchen ----------

    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>, depth: Int) {
        if (n == null || out.size >= 800 || depth > 40) return
        out.add(n)
        for (i in 0 until n.childCount) collect(n.getChildAt(i), out, depth + 1)
    }

    private fun isLikelyUsernameField(n: AccessibilityNodeInfo): Boolean {
        if (!n.isEditable || n.isPassword) return false
        val info = ((n.viewIdResourceName ?: "") + " " + (n.hintText?.toString() ?: "") + " " +
            (n.contentDescription?.toString() ?: "")).lowercase()
        return listOf("email", "e-mail", "mail", "user", "benutzer", "login", "konto", "account", "nutzer")
            .any { info.contains(it) }
    }

    private fun findForm(root: AccessibilityNodeInfo, pkg: String): LoginForm? {
        val nodes = ArrayList<AccessibilityNodeInfo>()
        collect(root, nodes, 0)

        // Adresszeile eines Browsers suchen
        var urlNode: AccessibilityNodeInfo? = null
        var url: String? = null
        for (n in nodes) {
            if (n.isPassword) continue
            val t = n.text?.toString()?.trim() ?: continue
            val id = (n.viewIdResourceName ?: "").lowercase()
            val looksLikeBar = n.isEditable || id.contains("url") || id.contains("address") || id.contains("omnibox") || id.contains("location")
            if (looksLikeBar && !t.contains(' ') && urlRegex.matches(t)) {
                urlNode = n
                url = t
                break
            }
        }
        val site = if (url != null) Site.normalize(url) else pkg.lowercase()

        val pwIndex = nodes.indexOfFirst { it.isPassword && it.isVisibleToUser }
        if (pwIndex >= 0) {
            var user: AccessibilityNodeInfo? = null
            for (i in pwIndex - 1 downTo 0) {
                val n = nodes[i]
                if (n.isEditable && !n.isPassword && n != urlNode && n.isVisibleToUser) {
                    user = n
                    break
                }
            }
            return LoginForm(pkg, site, nodes[pwIndex], user)
        }

        // 2-Schritt-Login: Nur E-Mail-/Benutzername-Feld auf dem Bildschirm (z. B. Disney+)
        val userOnly = nodes.firstOrNull { it != urlNode && it.isVisibleToUser && isLikelyUsernameField(it) }
        if (userOnly != null) {
            return LoginForm(pkg, site, null, userOnly)
        }
        return null
    }

    private fun readText(n: AccessibilityNodeInfo?): String {
        if (n == null) return ""
        val t = n.text?.toString()?.trim() ?: ""
        val hint = n.hintText?.toString()?.trim() ?: ""
        return if (t.isNotEmpty() && t != hint) t else ""
    }

    // ---------- Eintragen ----------

    private fun setText(n: AccessibilityNodeInfo, text: String) {
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun fill(form: LoginForm, c: Cred) {
        form.user?.let { if (c.username.isNotEmpty()) setText(it, c.username) }
        form.pass?.let { if (c.password.isNotEmpty()) setText(it, c.password) }
    }

    private fun openChooser(site: String) {
        val i = Intent(svc, FillAuthActivity::class.java)
            .putExtra("a11y", true)
            .putExtra("site", site)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            svc.startActivity(i)
        } catch (e: Exception) {
        }
    }

    private fun isIme(pkg: String): Boolean {
        val imm = svc.getSystemService(InputMethodManager::class.java) ?: return false
        return imm.enabledInputMethodList.any { it.packageName == pkg }
    }

    // ---------- Leiste ganz oben ----------

    private fun statusBarHeight(): Int {
        val id = svc.resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) svc.resources.getDimensionPixelSize(id) else svc.dp(24)
    }

    private fun show(key: String, text: String, onYes: () -> Unit) {
        hide()
        val ctx = svc
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = ctx.rounded(0xF2181D28.toInt(), 16)
        row.setPadding(ctx.dp(14), ctx.dp(10), ctx.dp(10), ctx.dp(10))

        val icon = ImageView(ctx)
        icon.setImageResource(R.drawable.ic_key)
        icon.setColorFilter(C.ACCENT)
        row.addView(icon, LinearLayout.LayoutParams(ctx.dp(22), ctx.dp(22)))

        val tv = ctx.label(text, 14f, C.TEXT)
        row.addView(
            tv,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).also {
                it.leftMargin = ctx.dp(10)
                it.rightMargin = ctx.dp(8)
            }
        )

        val no = ctx.label("✗", 22f, Color.WHITE, true)
        no.gravity = Gravity.CENTER
        no.background = ctx.rounded(C.CARD2, 12)
        no.setOnClickListener {
            dismissedKey = key
            hide()
        }
        row.addView(no, LinearLayout.LayoutParams(ctx.dp(44), ctx.dp(44)).also { it.rightMargin = ctx.dp(8) })

        val yes = ctx.label("✓", 22f, Color.WHITE, true)
        yes.gravity = Gravity.CENTER
        yes.background = ctx.rounded(C.ACCENT, 12)
        yes.setOnClickListener {
            dismissedKey = key
            hide()
            onYes()
        }
        row.addView(yes, LinearLayout.LayoutParams(ctx.dp(44), ctx.dp(44)))

        val wrap = FrameLayout(ctx)
        wrap.setPadding(ctx.dp(8), 0, ctx.dp(8), 0)
        wrap.addView(row)

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP
        lp.y = statusBarHeight() + ctx.dp(4)
        try {
            wm.addView(wrap, lp)
            bar = wrap
            shownKey = key
        } catch (e: Exception) {
        }
    }

    fun hide() {
        val b = bar
        if (b != null) {
            try {
                wm.removeView(b)
            } catch (e: Exception) {
            }
        }
        bar = null
        shownKey = null
    }
}
