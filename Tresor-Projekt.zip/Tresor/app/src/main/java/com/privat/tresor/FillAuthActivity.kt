package com.privat.tresor

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.service.autofill.Dataset
import android.view.Gravity
import android.view.autofill.AutofillId
import android.view.autofill.AutofillManager
import android.view.autofill.AutofillValue
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView

/** Wird vom Autofill-System gestartet: entsperrt kurz und liefert den gewaehlten Zugang zurueck. */
class FillAuthActivity : BaseActivity() {
    private var passId: AutofillId? = null
    private var userId: AutofillId? = null
    private var site = ""
    private var showAll = false
    private var a11y = false

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        passId = intent.getParcelableExtra<AutofillId>("passId")
        userId = intent.getParcelableExtra<AutofillId>("userId")
        site = intent.getStringExtra("site") ?: ""
        showAll = intent.getBooleanExtra("showAll", false)
        a11y = intent.getBooleanExtra("a11y", false)
        if ((passId == null && userId == null && !a11y) || !Vault.isSetUp(this)) {
            finish()
            return
        }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setPadding(dp(28), dp(64), dp(28), dp(28))
        root.setBackgroundColor(C.BG)
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(C.BG)
        scroll.isFillViewport = true
        scroll.addView(root)
        setContentView(scroll)

        val existing = Session.masterKey
        if (existing != null) {
            proceed(existing, false)
            return
        }
        val icon = ImageView(this)
        icon.setImageResource(R.drawable.ic_key)
        icon.setColorFilter(C.ACCENT)
        root.addView(icon, lp(dp(56), dp(56)))
        root.addView(label("Passwort aus dem Tresor", 22f, C.TEXT, true), lp(top = 16))
        val sub = label(if (site.isNotEmpty()) "für ${Site.displayName(site)}" else "", 14f, C.MUTED)
        sub.gravity = Gravity.CENTER
        root.addView(sub, lp(top = 6))
        val box = UnlockBox(this, "Entsperren") { key -> proceed(key, true) }
        root.addView(box.view, lp(top = 20))
        if (Vault.bioEnabled(this) && Bio.available(this)) window.decorView.post { box.unlockWithBio() }
    }

    private fun proceed(key: ByteArray, wipe: Boolean) {
        val creds = try {
            Vault.loadCreds(this, key)
        } catch (e: Exception) {
            mutableListOf<Cred>()
        }
        if (wipe) key.fill(0)
        if (creds.isEmpty()) {
            toast("Im Tresor sind noch keine Passwörter gespeichert.")
            finish()
            return
        }
        val matches = creds.filter { Site.matchesCred(it, site) }
        if (!showAll && matches.size == 1) {
            deliver(matches[0])
            return
        }
        val list = if (!showAll && matches.isNotEmpty()) matches else creds.sortedBy { it.title.lowercase() }
        val names = list.map { it.title + (if (it.username.isNotEmpty()) "  ·  " + it.username else "") }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Eintrag wählen")
            .setItems(names) { _, which -> deliver(list[which]) }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun deliver(c: Cred) {
        if (a11y) {
            A11yFill.set(c)
            finish()
            return
        }
        val ds = Dataset.Builder()
        passId?.let { ds.setValue(it, AutofillValue.forText(c.password)) }
        userId?.let { ds.setValue(it, AutofillValue.forText(c.username)) }
        setResult(RESULT_OK, Intent().putExtra(AutofillManager.EXTRA_AUTHENTICATION_RESULT, ds.build()))
        finish()
    }
}
