package com.privat.tresor

import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.text.TextUtils
import android.text.format.Formatter
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Switch
import android.widget.TextView
import androidx.core.content.FileProvider
import java.text.DateFormat
import java.util.Date

class FilesActivity : LockedActivity() {
    private val REQ_IMPORT = 11
    private val REQ_EXPORT = 12

    private sealed class ListItem {
        data class FolderItem(val name: String, val count: Int) : ListItem()
        data class FileItem(val entry: Entry) : ListItem()
    }

    private val items = ArrayList<ListItem>()
    private var allFolders = ArrayList<String>()
    private var currentFolder: String = ""

    private lateinit var adapter: BaseAdapter
    private lateinit var deleteSwitch: Switch
    private lateinit var titleView: TextView
    private lateinit var emptyView: TextView
    private lateinit var newFolderBtn: TextView
    private var pendingExport: Entry? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(C.BG)
        root.setPadding(dp(16), dp(12), dp(16), dp(16))

        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        val back = ImageView(this)
        back.setImageResource(R.drawable.ic_back)
        back.setColorFilter(C.TEXT)
        back.setPadding(dp(10), dp(10), dp(10), dp(10))
        back.setOnClickListener { navigateBack() }
        top.addView(back, lp(dp(44), dp(44)))

        titleView = label("Dateien-Tresor", 22f, C.TEXT, true)
        titleView.maxLines = 1
        titleView.ellipsize = TextUtils.TruncateAt.END
        top.addView(
            titleView,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).also { it.leftMargin = dp(6) }
        )

        newFolderBtn = label("＋ Ordner", 14f, C.ACCENT, true)
        newFolderBtn.background = rounded(C.CARD2, 12)
        newFolderBtn.setPadding(dp(12), dp(8), dp(12), dp(8))
        newFolderBtn.setOnClickListener { promptCreateFolder(null) }
        top.addView(newFolderBtn, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(top, lp())

        val listBox = FrameLayout(this)
        listBox.background = rounded(C.CARD, 20)
        val lv = ListView(this)
        lv.divider = null
        lv.selector = rounded(0x00000000, 0)
        emptyView = label("Noch keine Dateien.
Tippe unten auf „Dateien hinzufügen“ oder oben auf „＋ Ordner“.", 15f, C.MUTED)
        emptyView.gravity = Gravity.CENTER
        emptyView.setPadding(dp(20), dp(20), dp(20), dp(20))

        adapter = object : BaseAdapter() {
            override fun getCount() = items.size
            override fun getItem(position: Int) = items[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val item = items[position]
                val row = LinearLayout(this@FilesActivity)
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(dp(14), dp(10), dp(14), dp(10))

                val ic = ImageView(this@FilesActivity)
                ic.setPadding(dp(8), dp(8), dp(8), dp(8))
                ic.background = rounded(C.CARD2, 12)

                val col = LinearLayout(this@FilesActivity)
                col.orientation = LinearLayout.VERTICAL

                when (item) {
                    is ListItem.FolderItem -> {
                        ic.setImageResource(R.drawable.ic_folder)
                        ic.setColorFilter(C.ACCENT)
                        row.addView(ic, lp(dp(44), dp(44)))

                        val name = label(item.name, 16f, C.TEXT, true)
                        name.maxLines = 1
                        name.ellipsize = TextUtils.TruncateAt.END
                        col.addView(name)
                        val countText = if (item.count == 1) "1 Datei" else "${item.count} Dateien"
                        col.addView(label("Ordner  ·  $countText", 12f, C.MUTED))
                    }
                    is ListItem.FileItem -> {
                        val e = item.entry
                        ic.setImageResource(R.drawable.ic_file)
                        ic.setColorFilter(C.ACCENT)
                        row.addView(ic, lp(dp(44), dp(44)))

                        val name = label(e.name, 16f, C.TEXT)
                        name.maxLines = 1
                        name.ellipsize = TextUtils.TruncateAt.MIDDLE
                        col.addView(name)
                        col.addView(
                            label(
                                Formatter.formatFileSize(this@FilesActivity, e.size) + "  ·  " +
                                    DateFormat.getDateInstance().format(Date(e.added)),
                                12f,
                                C.MUTED
                            )
                        )
                    }
                }
                row.addView(
                    col,
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).also { it.leftMargin = dp(12) }
                )
                return row
            }
        }
        lv.adapter = adapter
        lv.emptyView = emptyView
        lv.setOnItemClickListener { _, _, pos, _ ->
            when (val item = items[pos]) {
                is ListItem.FolderItem -> {
                    currentFolder = item.name
                    refresh()
                }
                is ListItem.FileItem -> showActions(item.entry)
            }
        }
        lv.setOnItemLongClickListener { _, _, pos, _ ->
            when (val item = items[pos]) {
                is ListItem.FolderItem -> {
                    showFolderActions(item.name)
                    true
                }
                is ListItem.FileItem -> {
                    showActions(item.entry)
                    true
                }
            }
        }
        listBox.addView(lv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        listBox.addView(emptyView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(listBox, lp(h = 0, top = 8, weight = 1f))

        deleteSwitch = Switch(this)
        deleteSwitch.text = "Originale nach dem Import löschen"
        deleteSwitch.setTextColor(C.TEXT)
        deleteSwitch.isChecked = prefs.getBoolean("deleteOriginals", true)
        deleteSwitch.setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("deleteOriginals", c).apply() }
        root.addView(deleteSwitch, lp(top = 14))

        val add = button("＋  Dateien hinzufügen")
        add.setOnClickListener {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "*/*"
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            startActivityForResult(i, REQ_IMPORT)
        }
        root.addView(add, lp(top = 10))

        setContentView(root)
    }

    private fun navigateBack() {
        if (currentFolder.isNotEmpty()) {
            currentFolder = ""
            refresh()
        } else {
            finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (currentFolder.isNotEmpty()) {
            currentFolder = ""
            refresh()
        } else {
            super.onBackPressed()
        }
    }

    override fun onResume() {
        super.onResume()
        if (Session.masterKey != null) refresh()
    }

    private fun refresh() {
        val idx = try {
            Vault.loadIndex(this)
        } catch (e: Exception) {
            return
        }
        allFolders.clear()
        allFolders.addAll(idx.folders.sortedBy { it.lowercase() })

        if (currentFolder.isNotEmpty() && allFolders.none { it == currentFolder }) {
            currentFolder = ""
        }

        items.clear()
        if (currentFolder.isEmpty()) {
            titleView.text = "Dateien-Tresor"
            newFolderBtn.visibility = View.VISIBLE
            emptyView.text = "Noch keine Dateien oder Ordner.
Tippe unten auf „Dateien hinzufügen“ oder oben auf „＋ Ordner“."
            for (folder in allFolders) {
                val count = idx.files.count { it.folder == folder }
                items.add(ListItem.FolderItem(folder, count))
            }
            for (e in idx.files.filter { it.folder.isEmpty() }.sortedByDescending { it.added }) {
                items.add(ListItem.FileItem(e))
            }
        } else {
            titleView.text = currentFolder
            newFolderBtn.visibility = View.GONE
            emptyView.text = "Dieser Ordner ist noch leer.
Tippe unten auf „Dateien hinzufügen“."
            for (e in idx.files.filter { it.folder == currentFolder }.sortedByDescending { it.added }) {
                items.add(ListItem.FileItem(e))
            }
        }
        adapter.notifyDataSetChanged()
    }

    private fun promptCreateFolder(moveAfter: Entry?) {
        val input = EditText(this)
        input.hint = "Ordnername (z. B. Fotos, Dokumente)"
        input.setSingleLine(true)
        val pad = dp(20)
        val box = FrameLayout(this)
        box.setPadding(pad, dp(8), pad, 0)
        box.addView(input)

        AlertDialog.Builder(this)
            .setTitle("Neuen Ordner erstellen")
            .setView(box)
            .setPositiveButton("Erstellen") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isEmpty()) {
                    toast("Bitte einen Namen eingeben.")
                    return@setPositiveButton
                }
                try {
                    val ok = Vault.createFolder(this, name)
                    if (!ok) {
                        toast("Ein Ordner mit diesem Namen existiert bereits.")
                        return@setPositiveButton
                    }
                    if (moveAfter != null) {
                        Vault.moveFile(this, moveAfter, name)
                        toast("In „$name“ verschoben.")
                    } else {
                        toast("Ordner „$name“ erstellt.")
                    }
                    refresh()
                } catch (ex: Exception) {
                    toast("Fehler: ${ex.message}")
                }
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun showFolderActions(folderName: String) {
        AlertDialog.Builder(this)
            .setTitle("Ordner: $folderName")
            .setItems(arrayOf("Öffnen", "Umbenennen", "Ordner löschen")) { _, which ->
                when (which) {
                    0 -> {
                        currentFolder = folderName
                        refresh()
                    }
                    1 -> promptRenameFolder(folderName)
                    2 -> confirmDeleteFolder(folderName)
                }
            }
            .show()
    }

    private fun promptRenameFolder(oldName: String) {
        val input = EditText(this)
        input.setText(oldName)
        input.setSelection(oldName.length)
        input.setSingleLine(true)
        val pad = dp(20)
        val box = FrameLayout(this)
        box.setPadding(pad, dp(8), pad, 0)
        box.addView(input)

        AlertDialog.Builder(this)
            .setTitle("Ordner umbenennen")
            .setView(box)
            .setPositiveButton("Speichern") { _, _ ->
                val newName = input.text.toString().trim()
                if (newName.isEmpty()) return@setPositiveButton
                try {
                    if (Vault.renameFolder(this, oldName, newName)) {
                        if (currentFolder == oldName) currentFolder = newName
                        refresh()
                    } else {
                        toast("Name existiert bereits.")
                    }
                } catch (ex: Exception) {
                    toast("Fehler: ${ex.message}")
                }
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun confirmDeleteFolder(folderName: String) {
        AlertDialog.Builder(this)
            .setTitle("Ordner löschen?")
            .setMessage("Der Ordner „$folderName“ wird gelöscht. Dateien darin bleiben erhalten und landen wieder im Hauptordner.")
            .setPositiveButton("Löschen") { _, _ ->
                try {
                    Vault.deleteFolder(this, folderName)
                    if (currentFolder == folderName) currentFolder = ""
                    refresh()
                } catch (ex: Exception) {
                    toast("Fehler: ${ex.message}")
                }
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun showActions(e: Entry) {
        AlertDialog.Builder(this)
            .setTitle(e.name)
            .setItems(
                arrayOf(
                    "Öffnen",
                    "In Ordner verschieben",
                    "Entschlüsselt speichern (Export)",
                    "Aus dem Tresor löschen"
                )
            ) { _, which ->
                when (which) {
                    0 -> openFile(e)
                    1 -> showMoveDialog(e)
                    2 -> exportFile(e)
                    3 -> confirmDelete(e)
                }
            }
            .show()
    }

    private fun showMoveDialog(e: Entry) {
        val labels = ArrayList<String>()
        val targets = ArrayList<String?>()

        if (e.folder.isNotEmpty()) {
            labels.add("Hauptordner (kein Ordner)")
            targets.add("")
        }
        for (f in allFolders) {
            if (f != e.folder) {
                labels.add("📁  $f")
                targets.add(f)
            }
        }
        labels.add("＋  Neuen Ordner erstellen …")
        targets.add(null)

        AlertDialog.Builder(this)
            .setTitle("Verschieben nach")
            .setItems(labels.toTypedArray()) { _, which ->
                val target = targets[which]
                if (target == null) {
                    promptCreateFolder(e)
                } else {
                    try {
                        Vault.moveFile(this, e, target)
                        val dest = target.ifEmpty { "Hauptordner" }
                        toast("In „$dest“ verschoben.")
                        refresh()
                    } catch (ex: Exception) {
                        toast("Fehler: ${ex.message}")
                    }
                }
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun openFile(e: Entry) {
        val wait = AlertDialog.Builder(this).setMessage("Wird entschlüsselt …").setCancelable(false).show()
        Thread {
            try {
                val f = Vault.decryptToCache(this, e)
                runOnUiThread {
                    wait.dismiss()
                    val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
                    val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, e.mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    try {
                        startActivity(i)
                    } catch (ex: ActivityNotFoundException) {
                        toast("Keine App zum Öffnen dieser Datei gefunden.")
                    }
                }
            } catch (ex: Exception) {
                runOnUiThread {
                    wait.dismiss()
                    toast("Fehler beim Öffnen: ${ex.message}")
                }
            }
        }.start()
    }

    private fun exportFile(e: Entry) {
        pendingExport = e
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = e.mime
        i.putExtra(Intent.EXTRA_TITLE, e.name)
        startActivityForResult(i, REQ_EXPORT)
    }

    private fun confirmDelete(e: Entry) {
        AlertDialog.Builder(this)
            .setTitle("Löschen?")
            .setMessage("„${e.name}“ wird endgültig aus dem Tresor gelöscht.")
            .setPositiveButton("Löschen") { _, _ ->
                try {
                    Vault.removeFile(this, e)
                } catch (ex: Exception) {
                    toast("Fehler: ${ex.message}")
                }
                refresh()
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null || Session.masterKey == null) return
        when (requestCode) {
            REQ_IMPORT -> {
                val uris = ArrayList<Uri>()
                val clip = data.clipData
                if (clip != null) {
                    for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
                } else {
                    data.data?.let { uris.add(it) }
                }
                importAll(uris)
            }
            REQ_EXPORT -> {
                val target = data.data
                val e = pendingExport
                if (target != null && e != null) exportTo(e, target)
            }
        }
    }

    private fun importAll(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val delete = deleteSwitch.isChecked
        val targetFolder = currentFolder
        val wait = AlertDialog.Builder(this)
            .setTitle("Wird verschlüsselt …")
            .setMessage("Bitte kurz warten, bei großen Dateien kann das dauern.")
            .setCancelable(false)
            .show()
        Thread {
            var ok = 0
            var deleted = 0
            var failed = 0
            for (u in uris) {
                try {
                    Vault.importUri(this, u, targetFolder)
                    ok++
                    if (delete && tryDelete(u)) deleted++
                } catch (ex: Exception) {
                    failed++
                }
            }
            runOnUiThread {
                wait.dismiss()
                refresh()
                val where = if (targetFolder.isEmpty()) "den Tresor" else "den Ordner „$targetFolder“"
                var msg = "$ok Datei(en) in $where gelegt."
                if (delete && ok > 0) {
                    msg += if (deleted == ok) "
Originale wurden gelöscht."
                    else "
$deleted von $ok Originalen gelöscht. Die übrigen bitte selbst löschen (z. B. in Galerie oder Dateien)."
                }
                if (failed > 0) msg += "
$failed Datei(en) konnten nicht importiert werden."
                AlertDialog.Builder(this).setMessage(msg).setPositiveButton("OK", null).show()
            }
        }.start()
    }

    private fun tryDelete(u: Uri): Boolean {
        return try {
            DocumentsContract.deleteDocument(contentResolver, u)
        } catch (e: Exception) {
            try {
                contentResolver.delete(u, null, null) > 0
            } catch (e2: Exception) {
                false
            }
        }
    }

    private fun exportTo(e: Entry, target: Uri) {
        val wait = AlertDialog.Builder(this).setMessage("Wird entschlüsselt und gespeichert …").setCancelable(false).show()
        Thread {
            try {
                val os = contentResolver.openOutputStream(target) ?: throw IllegalStateException("Ziel nicht beschreibbar")
                os.use { Vault.decryptTo(this, e, it) }
                runOnUiThread {
                    wait.dismiss()
                    toast("Gespeichert.")
                }
            } catch (ex: Exception) {
                runOnUiThread {
                    wait.dismiss()
                    toast("Fehler beim Export: ${ex.message}")
                }
            }
        }.start()
    }
}
