package com.privat.tresor

import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.text.TextUtils
import android.text.format.Formatter
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Switch
import android.widget.TextView
import androidx.core.content.FileProvider
import java.text.DateFormat
import java.util.Date

class FilesActivity : LockedActivity() {
    private val REQ_IMPORT = 11
    private val REQ_EXPORT = 12

    private val entries = ArrayList<Entry>()
    private lateinit var adapter: BaseAdapter
    private lateinit var deleteSwitch: Switch
    private var pendingExport: Entry? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(C.BG)
        root.setPadding(dp(16), dp(12), dp(16), dp(16))

        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        val back = ImageView(this)
        back.setImageResource(R.drawable.ic_back)
        back.setColorFilter(C.TEXT)
        back.setPadding(dp(10), dp(10), dp(10), dp(10))
        back.setOnClickListener { finish() }
        top.addView(back, lp(dp(44), dp(44)))
        top.addView(label("Dateien-Tresor", 22f, C.TEXT, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).also { it.leftMargin = dp(6) })
        root.addView(top, lp())

        val listBox = FrameLayout(this)
        listBox.background = rounded(C.CARD, 20)
        val lv = ListView(this)
        lv.divider = null
        lv.selector = rounded(0x00000000, 0)
        val empty = label("Noch keine Dateien.\nTippe unten auf „Dateien hinzufügen“.", 15f, C.MUTED)
        empty.gravity = Gravity.CENTER
        adapter = object : BaseAdapter() {
            override fun getCount() = entries.size
            override fun getItem(position: Int) = entries[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val e = entries[position]
                val row = LinearLayout(this@FilesActivity)
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(dp(14), dp(10), dp(14), dp(10))
                val ic = ImageView(this@FilesActivity)
                ic.setImageResource(R.drawable.ic_file)
                ic.setColorFilter(C.ACCENT)
                ic.setPadding(dp(8), dp(8), dp(8), dp(8))
                ic.background = rounded(C.CARD2, 12)
                row.addView(ic, lp(dp(44), dp(44)))
                val col = LinearLayout(this@FilesActivity)
                col.orientation = LinearLayout.VERTICAL
                val name = label(e.name, 16f, C.TEXT)
                name.maxLines = 1
                name.ellipsize = TextUtils.TruncateAt.MIDDLE
                col.addView(name)
                col.addView(label(Formatter.formatFileSize(this@FilesActivity, e.size) + "  ·  " + DateFormat.getDateInstance().format(Date(e.added)), 12f, C.MUTED))
                row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).also { it.leftMargin = dp(12) })
                return row
            }
        }
        lv.adapter = adapter
        lv.emptyView = empty
        lv.setOnItemClickListener { _, _, pos, _ -> showActions(entries[pos]) }
        listBox.addView(lv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        listBox.addView(empty, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(listBox, lp(h = 0, top = 8, weight = 1f))

        deleteSwitch = Switch(this)
        deleteSwitch.text = "Originale nach dem Import löschen"
        deleteSwitch.setTextColor(C.TEXT)
        deleteSwitch.isChecked = prefs.getBoolean("deleteOriginals", true)
        deleteSwitch.setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("deleteOriginals", c).apply() }
        root.addView(deleteSwitch, lp(top = 14))

        val add = button("＋  Dateien hinzufügen")
        add.setOnClickListener {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "*/*"
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            startActivityForResult(i, REQ_IMPORT)
        }
        root.addView(add, lp(top = 10))

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (Session.masterKey != null) refresh()
    }

    private fun refresh() {
        val idx = try {
            Vault.loadIndex(this)
        } catch (e: Exception) {
            return
        }
        entries.clear()
        entries.addAll(idx.files.sortedByDescending { it.added })
        adapter.notifyDataSetChanged()
    }

    private fun showActions(e: Entry) {
        AlertDialog.Builder(this)
            .setTitle(e.name)
            .setItems(arrayOf("Öffnen", "Entschlüsselt speichern (Export)", "Aus dem Tresor löschen")) { _, which ->
                when (which) {
                    0 -> openFile(e)
                    1 -> exportFile(e)
                    2 -> confirmDelete(e)
                }
            }
            .show()
    }

    private fun openFile(e: Entry) {
        val wait = AlertDialog.Builder(this).setMessage("Wird entschlüsselt …").setCancelable(false).show()
        Thread {
            try {
                val f = Vault.decryptToCache(this, e)
                runOnUiThread {
                    wait.dismiss()
                    val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
                    val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, e.mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    try {
                        startActivity(i)
                    } catch (ex: ActivityNotFoundException) {
                        toast("Keine App zum Öffnen dieser Datei gefunden.")
                    }
                }
            } catch (ex: Exception) {
                runOnUiThread {
                    wait.dismiss()
                    toast("Fehler beim Öffnen: ${ex.message}")
                }
            }
        }.start()
    }

    private fun exportFile(e: Entry) {
        pendingExport = e
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = e.mime
        i.putExtra(Intent.EXTRA_TITLE, e.name)
        startActivityForResult(i, REQ_EXPORT)
    }

    private fun confirmDelete(e: Entry) {
        AlertDialog.Builder(this)
            .setTitle("Löschen?")
            .setMessage("„${e.name}“ wird endgültig aus dem Tresor gelöscht.")
            .setPositiveButton("Löschen") { _, _ ->
                try {
                    Vault.removeFile(this, e)
                } catch (ex: Exception) {
                    toast("Fehler: ${ex.message}")
                }
                refresh()
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null || Session.masterKey == null) return
        when (requestCode) {
            REQ_IMPORT -> {
                val uris = ArrayList<Uri>()
                val clip = data.clipData
                if (clip != null) {
                    for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
                } else {
                    data.data?.let { uris.add(it) }
                }
                importAll(uris)
            }
            REQ_EXPORT -> {
                val target = data.data
                val e = pendingExport
                if (target != null && e != null) exportTo(e, target)
            }
        }
    }

    private fun importAll(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val delete = deleteSwitch.isChecked
        val wait = AlertDialog.Builder(this)
            .setTitle("Wird verschlüsselt …")
            .setMessage("Bitte kurz warten, bei großen Dateien kann das dauern.")
            .setCancelable(false)
            .show()
        Thread {
            var ok = 0
            var deleted = 0
            var failed = 0
            for (u in uris) {
                try {
                    Vault.importUri(this, u)
                    ok++
                    if (delete && tryDelete(u)) deleted++
                } catch (ex: Exception) {
                    failed++
                }
            }
            runOnUiThread {
                wait.dismiss()
                refresh()
                var msg = "$ok Datei(en) in den Tresor gelegt."
                if (delete && ok > 0) {
                    msg += if (deleted == ok) "\nOriginale wurden gelöscht."
                    else "\n$deleted von $ok Originalen gelöscht. Die übrigen bitte selbst löschen (z. B. in Galerie oder Dateien)."
                }
                if (failed > 0) msg += "\n$failed Datei(en) konnten nicht importiert werden."
                AlertDialog.Builder(this).setMessage(msg).setPositiveButton("OK", null).show()
            }
        }.start()
    }

    private fun tryDelete(u: Uri): Boolean {
        return try {
            DocumentsContract.deleteDocument(contentResolver, u)
        } catch (e: Exception) {
            try {
                contentResolver.delete(u, null, null) > 0
            } catch (e2: Exception) {
                false
            }
        }
    }

    private fun exportTo(e: Entry, target: Uri) {
        val wait = AlertDialog.Builder(this).setMessage("Wird entschlüsselt und gespeichert …").setCancelable(false).show()
        Thread {
            try {
                val os = contentResolver.openOutputStream(target) ?: throw IllegalStateException("Ziel nicht beschreibbar")
                os.use { Vault.decryptTo(this, e, it) }
                runOnUiThread {
                    wait.dismiss()
                    toast("Gespeichert.")
                }
            } catch (ex: Exception) {
                runOnUiThread {
                    wait.dismiss()
                    toast("Fehler beim Export: ${ex.message}")
                }
            }
        }.start()
    }
}
