# Tresor – Anleitung (GitHub baut die APK)

## Einmalig einrichten
1. Auf github.com einloggen -> oben rechts "+" -> "New repository".
   Name z. B. `tresor`, auf **Private** stellen, "Create repository".
2. Im neuen Repository: "uploading an existing file" bzw. "Add file" -> "Upload files".
   Die Datei **Tresor-Projekt.zip** (diese ZIP, NICHT entpacken) auswaehlen, "Commit changes".
3. "Add file" -> "Create new file". Als Dateiname genau eingeben:
   `.github/workflows/build.yml`
   (beim Tippen der Schraegstriche entstehen die Ordner automatisch).
   Den Inhalt der Datei `build.yml` aus dieser ZIP hineinkopieren -> "Commit changes".
4. Oben auf "Actions" tippen. Der Lauf "APK bauen" startet automatisch (dauert ca. 3-6 Minuten).
   Wenn er gruen ist: fertig.

## APK holen
- Im Repository rechts/unten auf "Releases" -> neuester Eintrag "Tresor Build ..." -> **Tresor.apk** herunterladen.
- Alternativ: Actions -> Lauf anklicken -> unten "Artifacts" -> Tresor-APK (kommt als ZIP, entpacken).

## Installieren
- Tresor.apk antippen. Android fragt nach "Installation aus unbekannten Quellen" -> fuer den Browser/Dateimanager erlauben.
- App oeffnen -> Passwort festlegen -> Fingerabdruck aktivieren (optional).

## Updates
- Neue ZIP mit **gleichem Namen** hochladen (ersetzt die alte). Der Build startet automatisch.
- Die APK ist immer gleich signiert: neue Version einfach ueber die alte installieren, die Daten bleiben erhalten.
- NIEMALS die App deinstallieren, wenn Dateien im Tresor sind: dabei werden sie unwiderruflich geloescht.

## Wichtig zur Sicherheit
- Passwort vergessen = Dateien unwiederbringlich verloren (keine Wiederherstellung).
- Dateien im Tresor sind AES-256-verschluesselt und liegen nur im privaten App-Speicher.
- Die Apps im Hub sind durch die App-Sperre geschuetzt (siehe unten). Sie bleiben aber normal installiert.
- "Oeffnen" entschluesselt die Datei kurz in den privaten Cache der App. Beim Sperren wird er geleert.
- Die App sperrt sich selbst, wenn sie 60 Sekunden im Hintergrund war (Vault.kt, Konstante GRACE_MS).
- Screenshots und die Vorschau in der App-Uebersicht sind blockiert.

## App-Sperre (ab Version 1.1)
Alle Apps im Hub werden gesperrt: Beim Oeffnen kommt zuerst ein Entsperr-Bildschirm (Passwort oder Fingerabdruck).
Wer den Hub entsperrt, gibt alle Apps frei (Standard: 10 Minuten, einstellbar).

Einschalten:
1. Tresor oeffnen -> unten im Hub auf die rote Zeile "App-Sperre: NICHT aktiv" tippen.
2. "Bedienungshilfen oeffnen" -> Installierte Apps -> Tresor -> einschalten.
3. Falls der Schalter ausgegraut ist: "App-Info oeffnen" -> oben rechts ⋮ -> "Eingeschraenkte Einstellungen zulassen", dann Schritt 2 wiederholen.
4. In der App-Info -> Akku -> "Nicht eingeschraenkt" waehlen.
5. Empfohlen: Zeile "App-Sperre" antippen -> "Einstellungen-App sperren: An". So kann niemand die Sperre in den Einstellungen ausschalten.

Einstellungen (Zeile "App-Sperre" antippen): Freigabezeit, Sperre bei Bildschirm aus, Einstellungen-App sperren, alle Apps sofort sperren.
Das Schloss oben im Hub sperrt Tresor UND alle Apps sofort.

## Deinstallationsschutz (ab Version 1.2)
- Im Hub die Zeile "Deinstallationsschutz: aus" antippen -> Android-Dialog "Geraeteadministrator aktivieren" bestaetigen.
- Danach laesst sich der Tresor nicht mehr deinstallieren, solange der Schutz an ist.
- Ausschalten: Zeile im Hub antippen und Passwort eingeben (oder in den Android-Einstellungen unter Geraeteadministrator-Apps; mit "Einstellungen-App sperren" braucht man dort dein Passwort).
- Kein Schutz gegen Zuruecksetzen auf Werkseinstellungen, ADB per Computer oder jemanden, der dein Passwort kennt.
