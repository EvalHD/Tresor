# Tresor – Anleitung (GitHub baut die APK)

## Einmalig einrichten
1. Auf github.com einloggen -> oben rechts "+" -> "New repository".
   Name z. B. `tresor`, auf **Private** stellen, "Create repository".
2. Im neuen Repository: "uploading an existing file" bzw. "Add file" -> "Upload files".
   Die Datei **Tresor-Projekt.zip** (diese ZIP, NICHT entpacken) auswaehlen, "Commit changes".
3. "Add file" -> "Create new file". Als Dateiname genau eingeben:
   `.github/workflows/build.yml`
   (beim Tippen der Schraegstriche entstehen die Ordner automatisch).
   Den Inhalt der Datei `build.yml` aus dieser ZIP hineinkopieren -> "Commit changes".
4. Oben auf "Actions" tippen. Der Lauf "APK bauen" startet automatisch (dauert ca. 3-6 Minuten).
   Wenn er gruen ist: fertig.

## APK holen
- Im Repository rechts/unten auf "Releases" -> neuester Eintrag "Tresor Build ..." -> **Tresor.apk** herunterladen.
- Alternativ: Actions -> Lauf anklicken -> unten "Artifacts" -> Tresor-APK (kommt als ZIP, entpacken).

## Installieren
- Tresor.apk antippen. Android fragt nach "Installation aus unbekannten Quellen" -> fuer den Browser/Dateimanager erlauben.
- App oeffnen -> Passwort festlegen -> Fingerabdruck aktivieren (optional).

## Updates
- Neue ZIP mit **gleichem Namen** hochladen (ersetzt die alte). Der Build startet automatisch.
- Die APK ist immer gleich signiert: neue Version einfach ueber die alte installieren, die Daten bleiben erhalten.
- NIEMALS die App deinstallieren, wenn Dateien im Tresor sind: dabei werden sie unwiderruflich geloescht.

## Wichtig zur Sicherheit
- Passwort vergessen = Dateien unwiederbringlich verloren (keine Wiederherstellung).
- Dateien im Tresor sind AES-256-verschluesselt und liegen nur im privaten App-Speicher.
- Die Apps im Hub sind NUR verknuepft (Start per Tipp), nicht gesperrt. Eine App-Sperre kommt spaeter.
- "Oeffnen" entschluesselt die Datei kurz in den privaten Cache der App. Beim Sperren wird er geleert.
- Die App sperrt sich selbst, wenn sie 60 Sekunden im Hintergrund war (Vault.kt, Konstante GRACE_MS).
- Screenshots und die Vorschau in der App-Uebersicht sind blockiert.
